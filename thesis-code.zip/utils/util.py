# -*- coding: utf-8 -*-
# @fileName: util.py
# @Describe: 工具类函数
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2024/10/22

import csv
import os
from entities.entity_object import *
import logging


def compare_space(space1: Space, space2: Space) -> int:
    """
    按照到容器4个顶点的曼哈顿距离之和进行排序
    """
    if sum(space1.manhattan_distance) < sum(space2.manhattan_distance):
        return -1
    elif sum(space1.manhattan_distance) > sum(space2.manhattan_distance):
        return 1
    else:
        if space1.volume > space2.volume:
            return -1
        elif space1.volume < space2.volume:
            return 1
        else:
            if space1.manhattan_distance[0] < space2.manhattan_distance[0]:
                return -1
            elif space1.manhattan_distance[0] > space2.manhattan_distance[0]:
                return 1
            else:
                if space1.manhattan_distance[1] < space2.manhattan_distance[1]:
                    return -1
                elif space1.manhattan_distance[1] > space2.manhattan_distance[1]:
                    return 1
                else:
                    if space1.manhattan_distance[2] < space2.manhattan_distance[2]:
                        return -1
                    elif space1.manhattan_distance[2] > space2.manhattan_distance[2]:
                        return 1
                    else:
                        return 0


def compare_block(block1: Block, block2: Block) -> int:
    """
    根据block底面积、长、宽、高依次排序比较
    """
    if block1.l * block1.w < block2.l * block2.w:
        return 1
    elif block1.l * block1.w > block2.l * block2.w:
        return -1
    else:
        if block1.l < block2.l:
            return 1
        elif block1.l > block2.l:
            return -1
        else:
            if block1.w < block2.w:
                return 1
            elif block1.w > block2.w:
                return -1
            else:
                if block1.h < block2.h:
                    return 1
                elif block1.h > block2.h:
                    return -1
                else:
                    return 0


def compare_state(state1: PackingState, state2: PackingState) -> int:
    """
    自定义state比较函数，用于排序
    """
    if state1.fitness < state2.fitness:
        return 1
    elif state1.fitness > state2.fitness:
        return -1
    else:
        unloaded_volume1 = 0
        unloaded_volume2 = 0
        for b1 in state1.unloaded_blocks:
            unloaded_volume1 += b1.volume
        for b2 in state2.unloaded_blocks:
            unloaded_volume2 += b2.volume
        if unloaded_volume1 > unloaded_volume2:
            return -1
        elif unloaded_volume1 < unloaded_volume2:
            return 1
        else:
            return 0


def write_solution_to_csv(file_path: str, packing_state: PackingState) -> None:
    """
    write the packing solution to file
    """
    with open(file_path, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['container_id', 'box_id', 'order_id', 'l', 'w', 'h', 'x', 'y', 'z', 'rotation', 'origin_l', 'origin_w'])
        for i in range(len(packing_state.packing_sets)):
            for box in packing_state.packing_sets[i].loaded_boxes:
                rotation = 0
                if box.l != box.origin_l:
                    rotation = 90
                writer.writerow(
                    [i + 1, box.id, box.order_id, box.l, box.w, box.h, box.location.x, box.location.y, box.location.z,
                     rotation, box.origin_l, box.origin_w])
        writer.writerow(['load_rate', packing_state.avg_load_rate])


def write_block_solution_to_csv(file_path: str, packing_state: PackingState) -> None:
    """
    write the packing solution to file
    """

    with open(file_path, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        # writer.writerow(['container_id', 'box_id', 'order_id', 'l', 'w', 'h', 'x', 'y', 'z', 'rotation', 'origin_l', 'origin_w'])
        writer.writerow(['container_id', 'id', 'l', 'w', 'h', 'x', 'y', 'z', 'boxes_num'])
        for i in range(len(packing_state.packing_sets)):
            for block in packing_state.packing_sets[i].loaded_blocks:
                # rotation = 0
                # if box.l != box.origin_l:
                #     rotation = 90
                # writer.writerow(
                #     [i + 1, box.id, box.order_id, box.l, box.w, box.h, box.location.x, box.location.y, box.location.z,
                #      rotation, box.origin_l, box.origin_w])
                writer.writerow(
                    [i + 1, block.id,  block.l, block.w, block.h, block.location.x, block.location.y, block.location.z, len(block.boxes)])
        writer.writerow(['load_rate', packing_state.avg_load_rate])


def setup_logger(log_file_name: str):
    """
    配置日志记录器，支持将日志同时输出到控制台和文件。文件如果存在会覆盖重写。
    """
    logger = logging.getLogger("algorithm_logger")
    logger.setLevel(logging.DEBUG)  # 设置日志级别    # 避免重复添加处理器
    if logger.hasHandlers():
        logger.handlers.clear()
    # 创建文件处理器（覆盖模式 'w'，如需追加用 'a'）
    file_handler = logging.FileHandler(log_file_name, mode='w', encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)  # 设置日志级别
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)  # 也可以设为 INFO 以减少终端输出
    # 设置日志格式
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    # 添加处理器到 logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    return logger
