# -*- coding: utf-8 -*-
# @fileName: parameters.py
# @Describe: define the parameters of the algorithm
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2024/10/14
import sys


class Params:
    def __init__(self, gap=None, min_support_area_rate=None, height_diff_in_one_layer=None, max_load_length=None, max_load_width=None,
                 max_load_height=None, min_box_gap=None, out_length=None):
        # user defined parameters
        self.min_support_area_rate = min_support_area_rate
        self.max_load_length = max_load_length
        self.max_load_width = max_load_width
        self.max_load_height = max_load_height
        self.min_box_gap = min_box_gap
        self.min_box_height = sys.float_info.max
        self.gap = gap
        self.height_diff_in_one_layer = height_diff_in_one_layer
        self.max_length = max_load_length
        self.out_length = out_length
        # loading parameters
        self.min_composite_flr = 0.95
        self.max_projected_area_rate = 0.30  # maximum projected area rate of a box
        self.fix_container_cost = 500
        self.load_reward = 100
        self.unload_penalty = 300  # 出于减少装载容器数量的考虑
        self.load_rate_same_layer = 0.80  # 完美装载率
        self.load_rate_relax = 0.78  # 高层装载率
        self.usage_of_length = 500
        self.usage_of_width = 500
        self.usage_of_height = 700  # 对z轴施加较大的惩罚成本
        self.touch_area_reward = 0.75  # 接触面积奖励
        self.max_block_num = 5000
        self.random_factor = 2
        self.alpha = 2  # exponents of touch area rate
        self.time_limit = 45  # The maximum runtime of the algorithm

    def update_params(self, blocks: list) -> None:
        """
        Modify the min_box_gap and min_box_height parameter according to the unloaded block information.
        """
        self.min_box_gap = sys.float_info.max
        for block in blocks:
            self.min_box_gap = min(self.min_box_gap, block.l, block.w)
            self.min_box_height = min(self.min_box_height, block.h)
