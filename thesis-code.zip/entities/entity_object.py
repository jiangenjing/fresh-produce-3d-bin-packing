# -*- coding: utf-8 -*-
# @fileName: entity_object.py
# @Describe: define bin、subBin、item etc
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2024/10/13

from utils.parameters import *


class Location:
    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y and self.z == other.z


class Shape:
    def __init__(self, l: float, w: float, h: float):
        self.l = l
        self.w = w
        self.h = h

    def __eq__(self, other):
        return self.l == other.l and self.w == other.w and self.h == other.h


class Box:
    def __init__(self, id=None, order_id=None, contract_id=None, l=None, w=None, h=None):
        self.id = id
        self.order_id = order_id
        self.contract_id = contract_id
        self.l = l
        self.w = w
        self.h = h
        self.volume = l * w * h
        # 主要用于识别箱子是否旋转放置
        self.origin_l = l
        self.origin_w = w
        self.origin_h = h
        self.direction = 0  # 默认为原方向
        self.already_loaded = False

    def __eq__(self, other):
        if isinstance(other, Box):
            return self.id == other.id
        return False


class Block:
    def __init__(self, l=None, w=None, h=None):
        self.l = l
        self.w = w
        self.h = h
        self.volume = 0.0
        self.location = None
        self.boxes = []
        self.relative_location = []
        self.not_fit_exact_combination = 0  # 标识不适合同层装载的程度，0-适合装载，1-略微不适合，2-非常不适合
        self.already_loaded = False  # 标识是否已经装载
        self.vcs = None
        self.id = None  # 标识block

    def __eq__(self, other):
        if isinstance(other, Block):
            if self.l == other.l and self.w == other.w and self.h == other.h and len(self.boxes) == len(self.boxes):
                for box in self.boxes:
                    if box not in other.boxes:
                        return False
                return True
        return False


class Space:
    def __init__(self, location: Location, shape: Shape, front: float, back: float, left: float, right: float):
        self.location = location
        self.shape = shape
        self.front = front
        self.back = back
        self.left = left
        self.right = right
        self.volume = (shape.l + front + back) * (shape.w + left + right) * shape.h
        # anchor point of the space
        self.manhattan_distance = [0, 0, 0]
        self.anchor_index = [0, 0, 0]

    def __eq__(self, other):
        if isinstance(other, Space):
            return self.location == other.location and self.shape == other.shape and self.front == other.front and self.back == other.back and \
                self.left == other.left and self.right == other.right
        return False

    def set_anchor(self, params: Params) -> None:
        """
        Set the anchor point of the space. The anchor angle arises from the four corners of the bottom surface of the space
        """
        # x direction
        if self.location.x <= params.max_load_length - (self.location.x + self.shape.l):
            self.anchor_index[0] = 0
            self.manhattan_distance[0] = self.location.x
        else:
            self.anchor_index[0] = 1
            self.manhattan_distance[0] = params.max_load_length - (self.location.x + self.shape.l)
        # y direction
        if self.location.y <= params.max_load_width - (self.location.y + self.shape.w):
            self.anchor_index[1] = 0
            self.manhattan_distance[1] = self.location.y
        else:
            self.anchor_index[1] = 1
            self.manhattan_distance[1] = params.max_load_width - (self.location.y + self.shape.w)
        # z direction: consider that boxed require support stability to be loaded
        self.anchor_index[2] = 0
        self.manhattan_distance[2] = self.location.z
        self.manhattan_distance.sort()  # 对space四个角到容器corner的曼哈顿距离进行排序


class PackingSet:
    def __init__(self):
        self.loaded_blocks = None  # blocks that have been loaded
        self.loaded_boxes = None  # boxes that have been loaded（已装载的箱子位置信息也需要还原）
        self.spaces = None  # free spaces
        self.loaded_volume = None  # volume of loaded boxes
        self.load_rate = None
        self.min_border = [0, 0, 0]
        self.start = Location(0, 0, 0)

    def __eq__(self, other):
        # comparing the loaded boxes is ok!
        if isinstance(other, PackingSet):
            if len(self.loaded_blocks) != len(other.loaded_blocks):
                return False
            if self.loaded_volume != other.loaded_volume or self.load_rate != other.load_rate:
                return False
            for box in self.loaded_boxes:
                if box not in other.loaded_boxes:
                    return False
            return True
        return False

    def initialize(self) -> None:
        """
        初始化装载方案
        """
        self.loaded_blocks = []
        self.loaded_boxes = []
        self.loaded_volume = 0
        self.load_rate = 0
        self.spaces = []

    def evaluate(self, params: Params) -> None:
        """
        计算装载率，但并非简单的已装载box总体积/容器总体积
        """
        self.min_border[0] = params.max_length
        self.min_border[1] = params.max_load_width

        if len(self.loaded_blocks) == 0:
            self.load_rate = 0
        else:
            for block in self.loaded_blocks:
                self.min_border[2] = max(self.min_border[2], block.location.z + block.h)
            self.load_rate = self.loaded_volume / (params.max_length * params.max_load_width * self.min_border[2])


class PackingState:
    def __init__(self, unloaded_blocks=None):
        self.unloaded_blocks = unloaded_blocks  # blocks to be loaded
        self.packing_sets = []  # packing sets
        self.avg_load_rate = 0.0  # average load rate
        self.current_load_rate = 0.0  # current load rate
        self.fitness = 0.0  # fitness of simultaneous loading
        self.times = 1  # 标识出现次数

    def __eq__(self, other):
        """
        主要比较simulated_fitness和avg_load_rate，以及装箱方案和待装载block
        """
        if isinstance(other, PackingState):
            return self.fitness == other.fitness and self.avg_load_rate == other.avg_load_rate \
                and len(self.packing_sets) == len(other.packing_sets) and len(self.unloaded_blocks) == len(other.unloaded_blocks)
        return False

    def evaluate(self, params: Params) -> None:
        # # 计算fitness：第一个容器装载越多越好
        # reward_load_rate = self.calculate_final_load_rate(params)
        # # reward_load_rate = self.packing_sets[0].loaded_volume / (params.max_length * params.max_load_width * params.max_load_height)
        # self.fitness = reward_load_rate * params.load_reward - len(self.packing_sets) * params.fix_container_cost
        # # 计算平均装载率
        # total_loaded_volume = 0.0
        # total_volume = 0.0
        # for i in range(len(self.packing_sets)):
        #     self.packing_sets[i].evaluate(params)
        #     total_loaded_volume += self.packing_sets[i].loaded_volume
        #     total_volume += self.packing_sets[i].min_border[0] * self.packing_sets[i].min_border[1] * self.packing_sets[i].min_border[2]
        # self.avg_load_rate = total_loaded_volume / total_volume
        # # 计算当前装载率
        unloaded_num_list = []
        total_loaded_volume = 0.0
        total_volume = 0.0
        weighted_load_rate_numerator = 0.0
        weitghted_load_rate_denominator = 0.0
        for i in range(len(self.packing_sets)):
            total_loaded_volume += self.packing_sets[i].loaded_volume
            total_volume += self.packing_sets[i].min_border[0] * self.packing_sets[i].min_border[1] * self.packing_sets[i].min_border[2]
            weighted_load_rate_numerator += self.packing_sets[i].load_rate * 10 ** (len(self.packing_sets) - i - 1)
            weitghted_load_rate_denominator += 10 ** (len(self.packing_sets) - i - 1)
            if i > 0:
                unloaded_num_list.append(len(self.packing_sets[i].loaded_boxes))

        # 计算装载方案fitness
        self.fitness = (weighted_load_rate_numerator / weitghted_load_rate_denominator * params.load_reward - len(self.packing_sets) *
                                  params.fix_container_cost)
        for i in range(len(unloaded_num_list)):
            self.fitness -= unloaded_num_list[i] * params.unload_penalty
        if total_volume == 0:
            self.avg_load_rate = 0
        else:
            self.avg_load_rate = total_loaded_volume / total_volume

    def calculate_current_load_rate(self, params: Params) -> float:
        """
        主要考虑第一个容器的当前装载率
        """
        return self.packing_sets[0].loaded_volume / (params.max_length * params.max_load_width * params.max_load_height)

    def calculate_final_load_rate(self, params: Params) -> float:
        """
        主要考虑第一个容器的装载率
        """
        self.packing_sets[0].min_border[2] = 0
        for box in self.packing_sets[0].loaded_boxes:
            self.packing_sets[0].min_border[2] = max(self.packing_sets[0].min_border[2], box.location.z + box.h)
        if self.packing_sets[0].min_border[2] == 0:
            return 0
        return self.packing_sets[0].loaded_volume / (params.max_length * params.max_load_width * self.packing_sets[0].min_border[2])
