# -*- coding: utf-8 -*-
# @fileName: main.py
# @Describe: 
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2025/02/20
import os 
import sys

# 添加项目根目录到 Python 路径
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.append(project_root)

from algo.pack_tool import *
from dao.data_process import *
from utils.util import *
from datetime import datetime
import time

def main(file_path: str, log_path: str, output_path=None, result_txt=None) -> None:
    logger = setup_logger(log_path)
    logger.info('Loading data...')
    instance_list = load_data_from_csv(file_path)
    
    # 添加调试信息
    logger.info(f'加载了 {len(instance_list)} 个实例')
    for i, instance in enumerate(instance_list):
        logger.info(f'实例 {i+1}:')
        logger.info(f'名称: {instance.name}')
        logger.info(f'参数: {instance.params}')
        logger.info(f'箱子数量: {len(instance.boxes) if hasattr(instance, "boxes") else "未知"}')
    
    with open(result_txt, 'w', newline='', encoding='utf-8') as file:
        # writer = csv.writer(file)
        # # 如果是新文件，写入表头
        file.write('算例,装载率,计算时长\n')
        for instance in instance_list:
            logger.info(f'开始处理实例: {instance.name}')
            pack_tool = PackTool(instance.params, logger)
            start_time = time.perf_counter()
            best_state = pack_tool.main_algo(instance)
            end_time = time.perf_counter()
            execution_time = end_time - start_time
            load_rate = best_state.calculate_final_load_rate(instance.params)
            logger.info(f'实例 {instance.name} 的装载率: {load_rate:.2f}')
            line = f'{instance.name},{round(load_rate, 2)},{execution_time: .6f}\n'
            file.write(line)
            output_file = os.path.join(project_root, 'test0226', f'{instance.name}-{round(load_rate, 2)}.csv')
            output_dir = os.path.dirname(output_file)
            if not os.path.exists(output_dir):
                os.makedirs(output_dir, exist_ok=True)
            write_solution_to_csv(output_file, best_state)
    return


if __name__ == '__main__':

    # 获取项目根目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(current_dir)

    # 设置文件路径
    file_path = os.path.join(project_root, 'test.csv')
    output_dir = os.path.join(project_root, 'output')
    log_dir = os.path.join(output_dir, 'log')
    result_txt = os.path.join(project_root, 'result_0514.txt')
    output_path = os.path.join(project_root, '01.csv')

    # 创建必要的目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_path = os.path.join(log_dir, f'log_{current_time}.log')

    # 3. Pass correct path into your main function (and anywhere else!)
    # Assuming you have a main function defined elsewhere:
    try:
        logger = setup_logger(log_path) # setup logger
        main(file_path, log_path, output_path, result_txt)
    except Exception as e:
        if logger:
            logger.exception("An error occurred: %s", e)
        else:
            print(f"An error occurred: {e}")


