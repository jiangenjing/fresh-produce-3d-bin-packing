import pandas as pd
import numpy as np

rows = []
for customer_id in range(1, 9):
    for i in range(1, 36):
        length = np.random.randint(200, 501)
        width = np.random.randint(70, 501)
        height = np.random.randint(100, 701)
        row = {
            '包编号': (customer_id-1)*35 + i,
            '包件描述': 'A',
            '板件数': 1,
            '包长': length,
            '包宽': width,
            '包厚': height,
            '长': length,
            '宽': width,
            '高': height,
            '订单号': customer_id,
            '合同号': customer_id,
            '客户号': customer_id
        }
        rows.append(row)

df = pd.DataFrame(rows)
df.to_csv('随机算例.csv', index=False, encoding='utf-8-sig')
print('已生成：随机算例.csv')
