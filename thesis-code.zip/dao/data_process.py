# -*- coding: utf-8 -*-
# @fileName: data_process.py
# @Describe: 
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2025/02/19

import os.path
import sys
import json
from dao.instance import Instance
from entities.entity_object import Box
from utils.parameters import Params
import pandas as pd


def load_data(file_path: str) -> list():
    """
    read instance data from txt file
    """
    with open(file_path, 'r') as file:
        data = json.load(file)  # 将json文件内容加载到python字典
        data = data['data']

        instance = Instance()
        # get file name
        file_name_os = os.path.basename(file_path)
        instance.name = os.path.splitext(file_name_os)[0].split('_')[0]
        # get load parameters
        instance.params = Params(float(data['paramInfo']['boxSpace']),
                                 float(data['paramInfo']['belowInitSupportRatio']),
                                 float(data['paramInfo']['heightDifferInOneLayer']),
                                 float(data['paramInfo']['palletLength']),
                                 float(data['paramInfo']['palletWidth']), float(data['paramInfo']['maxPalletHeight']),
                                 sys.float_info.max, float(data['paramInfo']['palletOutLength']))
        instance.params.max_load_length += instance.params.out_length * 2
        instance.params.max_length = instance.params.max_load_length
        # get box information
        for box in data['boxes']:
            h = float(box['boxHeight'])
            l = float(box['boxLength'])
            w = float(box['boxWidth'])
            box_obj = Box(box['boxCode'], box['orderCode'], box['batchCode'], l=l, w=w, h=h)
            instance.boxes.append(box_obj)

            if instance.id is None:
                instance.id = box['batchCode']

            instance.params.min_box_gap = min(instance.params.min_box_gap, l, w)
            instance.params.min_box_height = min(instance.params.min_box_height, h)
            instance.params.max_length = max(instance.params.max_length, l)
    return [instance]


def load_data_from_csv(file_path: str) -> list():
    """
    read instance data from csv file
    """
    try:
        df = pd.read_csv(file_path, encoding='utf-8')
    except UnicodeDecodeError:
        df = pd.read_csv(file_path, encoding='gbk')  # 中文系统常用编码
    instance_list = dict()  # key存放instance的id，value存放instance对象
    for index, row in df.iterrows():
        instance_id = row['客户号']
        if instance_id not in instance_list:
            new_instance = Instance()
            new_instance.id = instance_id
            new_instance.name = instance_id
            params = Params(0, 0.75, 15, 1100, 1100, 1500, sys.float_info.max, 10)
            new_instance.params = params
            instance_list[instance_id] = new_instance
        instance = instance_list[instance_id]
        box = Box(row['包编号'], row['订单号'], row['客户号'], l=float(row['包长']), w=float(row['包宽']), h=float(row['包厚']))
        instance.boxes.append(box)
        instance.params.max_load_width = max(instance.params.max_load_width, box.w)
        instance.params.max_length = max(instance.params.max_length, box.l)
    return list(instance_list.values())  # 返回instance对象的列表
