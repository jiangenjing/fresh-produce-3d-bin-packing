# -*- coding: utf-8 -*-
# @fileName: instance.py
# @Describe: A 3D bin packing problem instance
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2024/10/14

import sys


class Instance:
    def __init__(self):
        self.id = None
        self.name = None
        self.boxes = []  # double linked list to store boxes
        self.params = None  # parameters of the algorithm
