# -*- coding: utf-8 -*-
# @fileName: star_pack.py
# @Describe: 主要用于鑫光项目的装箱算法
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2024/11/15

import copy
import math
from functools import cmp_to_key
from dao.instance import *
import random
from typing import List, Tuple
from utils.util import *
import time


class Pack:
    def __init__(self, params: Params, logger=None):
        self.params = params
        self.logger = logger

    def main_algo(self, instance: Instance) -> PackingState:
        self.logger.info("Start generating blocks...")
        # 生成block
        start_time = time.time()
        blocks_dict, heights = self.generate_blocks(instance)
        self.logger.info("Blocks generated!")
        # 进行同层装载
        self.logger.info('Loading blocks in the same layer...')
        state = self.get_same_layer_loaded_packing_state(blocks_dict, heights)
        state.packing_sets[-1].evaluate(self.params)
        state.evaluate(self.params)
        self.logger.info('Blocks loaded in the same layer!')
        # 进行beam search
        self.logger.info('Start beam searching to Load left blocks in the container...')
        best_state = self.beam_search(state, 6, 3)
        end_time = time.time()
        self.logger.info(f'All blocks are loaded, and average load rate is {best_state.avg_load_rate: .2%}!')
        # 输出算法运行时长
        self.logger.info(f'Time cost: {end_time - start_time:.2f}s')
        return best_state

    # =============================================== 树搜索类函数 ===============================================
    def beam_search(self, state: PackingState, candidate_length: int, space_width=1) -> PackingState:
        """
        For a given state, to find the best loading solution by beam-searching.
        """
        self.logger.info("Start beam search...")
        # 装载参数修正
        self.params.update_params(state.unloaded_blocks)
        # 进行初始状态扩展
        state_queue = [copy.deepcopy(state)]  # state_queue存放候选状态
        best_state = None
        best_fitness = -sys.float_info.max
        ite = 0  # 记录迭代次数
        while len(state_queue) > 0:
            ite += 1
            # 判断当前是否已经找到最优解
            for state in state_queue:
                if len(state.unloaded_blocks) == 0:
                    # 计算全部packing_set装载率
                    for packing_set in state.packing_sets:
                        packing_set.evaluate(self.params)
                    # 计算平均装载率
                    state.evaluate(self.params)
                    state_queue.remove(state)  # 该节点已经到达最终状态，从队列中删除
                    # 如果该节点存在多个packing_set，则需要进一步优化
                    if len(state.packing_sets) > 1:
                        if state.times < len(state.packing_sets):
                            state = self.reset_packing_state(state, state.times)
                            state.times += 1
                            state_queue.append(state)
                    if state.fitness > best_fitness:
                        best_fitness = state.fitness
                        best_state = state
                        self.logger.info(f"Find a better solution: {best_state.fitness:.5f}")

            if len(state_queue) > 0:
                # 每次选择适应度最高的一个state进行扩展
                self.logger.info(f"Extending node_{ite}, current fitness: {state_queue[0].fitness:.5f}," f" current load rate: {state_queue[0].avg_load_rate:.2%}")
                current_state = state_queue.pop(0)  # 默认对队列中packing state做了适应度降序排列
                extended_states = self.extend_state(current_state, space_width)  # 节点扩展
                for key in extended_states.keys():
                    if extended_states[key][1].fitness > best_fitness:
                        best_state = extended_states[key][1]
                        best_fitness = best_state.fitness
                        self.logger.info(f"Find a better solution: {best_state.fitness:.5f}")
                    if extended_states[key][0] in state_queue:
                        continue
                    state_queue.append(extended_states[key][0])
                # 对packing state队列进行剪枝
                state_queue = self.pruning(state_queue, candidate_length)
        return best_state

    def pruning(self, state_queue: list, candidate_length: int) -> list:
        """
        对备选状态队列进行剪枝，保留适应度最高的candidate_length个状态，主要比较simulated fitness和unloaded blocks的个数
        """
        can_removable_state = []
        new_state_queue = []
        state_queue.sort(key=cmp_to_key(compare_state))
        for i in range(len(state_queue) - 1):
            if state_queue[i] in can_removable_state:
                continue
            for j in range(i + 1, len(state_queue)):
                if state_queue[j] in can_removable_state:
                    continue
                # state_queue[i]严格占优state_queue[j]，则state_queue[j]可以被删除
                if state_queue[i].fitness > state_queue[j].fitness and \
                        len(state_queue[i].unloaded_blocks) < len(state_queue[j].unloaded_blocks) and \
                        state_queue[i].avg_load_rate > state_queue[j].avg_load_rate:
                    can_removable_state.append(state_queue[j])
        nums = min(candidate_length, len(state_queue) - len(can_removable_state))
        idx = 0
        while len(new_state_queue) < nums and idx < len(state_queue):
            if state_queue[idx] not in can_removable_state:
                new_state_queue.append(state_queue[idx])
            idx += 1
        return new_state_queue

    def extend_state(self, state: PackingState, space_width=1) -> list:
        """
        选择空闲子空间，返回扩展后的列表，默认space width = 1
        """
        extended_states = dict()
        # 获取candidate block
        candidate_blocks = self.get_candidate_blocks(state.unloaded_blocks)
        if len(candidate_blocks) > 0:
            for block in candidate_blocks:
                states = self.get_candidate_state_for_block_loading(block, state, space_width)
                for s in states:
                    simul_state = copy.deepcopy(s)
                    s.fitness, s.avg_load_rate = self.loaded_simulation_default(simul_state)
                    if s.fitness not in extended_states.keys():
                        extended_states[s.fitness] = [s, simul_state]
                    else:
                        if s.avg_load_rate > extended_states[s.fitness][0].avg_load_rate:
                            extended_states[s.fitness] = [s, simul_state]
        return extended_states


    def get_candidate_state_for_block_loading(self, block: Block, packing_state: PackingState, space_width: int) -> list:
        """
        For a given block, to find some spaces to load, and return the ranked packing state.
        """
        candidate_states = []  # 存放候选状态
        i = 0  # 表示当前装载容器
        while i < len(packing_state.packing_sets):
            candidate_info = []  # 存放候选装载信息：container_id, space_index, block, location, f1, f2, f3
            candidate_info_map = dict()  # 方便后面识别space
            for j in range(len(packing_state.packing_sets[i].spaces)):
                current_space = packing_state.packing_sets[i].spaces[j]
                current_loaded, location = self.check_loadable(block, current_space, packing_state.packing_sets[i].loaded_boxes, packing_state.packing_sets[i].spaces)
                if current_loaded:
                    f1 = self.get_fitness_of_space_1(block, location, current_space, packing_state.packing_sets[i])
                    f2 = self.get_fitness_of_space_2(block, location, current_space, packing_state.packing_sets[i])
                    f3 = self.get_fitness_of_space_3(block, location, current_space, packing_state.packing_sets[i])
                    candidate_info.append([i, j, block, location, f1, f2, f3])
                    candidate_info_map[j] = [i, j, block, location, f1, f2, f3]
            if candidate_info:
                space_idx = []  # 存储值得装载的space索引
                # 根据f1筛选空闲子空间
                candidate_info.sort(key=lambda x: x[4], reverse=True)
                num1 = min(space_width, len(candidate_info))
                for k in range(num1):
                    if candidate_info[k][1] not in space_idx:
                        space_idx.append(candidate_info[k][1])
                # 根据f2筛选空闲子空间
                candidate_info.sort(key=lambda x: x[5], reverse=True)
                num2 = min(space_width, len(candidate_info))
                for k in range(num2):
                    if candidate_info[k][1] not in space_idx:
                        space_idx.append(candidate_info[k][1])
                # 根据f3筛选空闲子空间
                candidate_info.sort(key=lambda x: x[6], reverse=True)
                num3 = min(space_width, len(candidate_info))
                for k in range(num3):
                    if candidate_info[k][1] not in space_idx:
                        space_idx.append(candidate_info[k][1])
                # 添加扩展状态
                for idx in space_idx:
                    candidate_state = copy.deepcopy(packing_state)
                    info = candidate_info_map[idx]
                    self.make_block_loaded(info[2], info[3], candidate_state.packing_sets[info[0]], candidate_state)
                    candidate_states.append(candidate_state)
                break  # 直接可以跳出循环，不必再寻找空闲子空间
            else:
                if i == len(packing_state.packing_sets) - 1:  # 寻找到最后一个packing_set都没有找到合适的装载位置
                    # 新增一个packing_set
                    new_packing_set = PackingSet()
                    new_packing_set.initialize()
                    new_packing_set.spaces = [Space(Location(0, 0, 0), Shape(self.params.max_length, self.params.max_load_width,
                                                                             self.params.max_load_height), 0, 0, 0, 0)]
                    packing_state.packing_sets.append(new_packing_set)
            i += 1
        return candidate_states

    def get_candidate_blocks(self, blocks: list) -> list:
        """
                分别找出底面积、长、宽排名前2的block作为下一个装载的候选block
                """
        candidate_blocks = []
        indexs = [-1 for _ in range(6)]  # 记录已经选中的block的索引
        # ============================== 主要出于丰富候选block多样性的考虑 ==============================
        # 首选选择底面积最大的block
        max_area = 0.0
        for i in range(len(blocks)):
            if blocks[i].l * blocks[i].w > max_area:
                max_area = blocks[i].l * blocks[i].w
                indexs[0] = i
            elif blocks[i].l * blocks[i].w == max_area:
                if blocks[i].w > blocks[indexs[0]].w:
                    indexs[0] = i
        # 第2选择长边最长的block
        max_l = 0.0
        for i in range(len(blocks)):
            if i == indexs[0]:
                continue
            if blocks[i].l > max_l:
                max_l = blocks[i].l
                indexs[1] = i
        # 第3选择宽边最长的block
        max_w = 0.0
        for i in range(len(blocks)):
            if i == indexs[0] or i == indexs[1]:
                continue
            # 考虑两种情况，其一，block的宽是原本的宽
            if blocks[i].w > max_w:
                max_w = blocks[i].w
                indexs[2] = i
        # 第4选择底面积第二大的block(不必考虑和长边比较)
        second_area = 0.0
        for i in range(len(blocks)):
            if i == indexs[0] or i == indexs[1] or i == indexs[2]:
                continue
            if blocks[i].l * blocks[i].w > second_area:
                second_area = blocks[i].l * blocks[i].w
                indexs[3] = i
        # 第5选择长边第二长的block
        second_l = 0.0
        for i in range(len(blocks)):
            if i == indexs[0] or i == indexs[1] or i == indexs[2] or i == indexs[3]:
                continue
            if blocks[i].l > second_l:
                second_l = blocks[i].l
                indexs[4] = i
        # 第6选择宽边第二长的block
        second_w = 0.0
        for i in range(len(blocks)):
            if i == indexs[0] or i == indexs[1] or i == indexs[2] or i == indexs[3] or i == indexs[4]:
                continue
            if blocks[i].w > second_w:
                second_w = blocks[i].w
                indexs[5] = i
        # 添加候选block
        for idx in indexs:
            if idx != -1:
                candidate_blocks.append(blocks[idx])
        return candidate_blocks

    # =============================================== 默认规则模拟装载类函数 ===============================================
    def reset_packing_state(self, state: PackingState, level=1) -> PackingState:
        """
        To reduce the number of loading containers, reset the extra packing set and the parameter level is to identify the number of retained containers.
        """
        new_state = copy.deepcopy(state)
        # 根据level的标识重置packing_sets
        new_state.packing_sets = state.packing_sets[:level]  # 保留level个packing_set
        for i in range(level, len(state.packing_sets)):
            for block in state.packing_sets[i].loaded_blocks:
                block.already_loaded = False
                # 重置与已装载block相关的box旋转方向信息
                for box in block.boxes:
                    box.already_loaded = False
                new_state.unloaded_blocks.append(block)
        return new_state

    def load_blocks_default(self, state: PackingState) -> None:
        """
        按照默认规则一个个装载block
        """
        state.unloaded_blocks.sort(key=cmp_to_key(compare_block))
        while len(state.unloaded_blocks) > 0:
            block = state.unloaded_blocks[0]  # 取第一个block
            # 选择空闲子空间进行装载
            idx = 0  # 标识需要选取的packing_set索引
            while idx < len(state.packing_sets):
                packing_set = state.packing_sets[idx]
                loaded = False
                best_block = Block()
                best_direction = -1
                best_location = Location(-1, -1, -1)
                best_fitness = -sys.float_info.max
                for space in packing_set.spaces:
                    current_loaded, current_block, current_location, current_direction = self.find_best_direction_loaded(block, space, packing_set)
                    if current_loaded:
                        loaded = True
                        if self.get_fitness_of_space_1(current_block, current_location, space, packing_set) > best_fitness:
                            best_block = current_block
                            best_direction = current_direction
                            best_location = current_location
                            best_fitness = self.get_fitness_of_space_1(current_block, current_location, space, packing_set)
                if loaded:
                    self.make_block_loaded(best_block, best_location, packing_set, state, direction=best_direction)
                    break
                else:
                    if idx == len(state.packing_sets) - 1:
                        new_packing_set = PackingSet()
                        new_packing_set.initialize()
                        new_packing_set.spaces = [Space(Location(0, 0, 0), Shape(self.params.max_length, self.params.max_load_width,
                                                                                 self.params.max_load_height), 0, 0, 0, 0)]
                        state.packing_sets.append(new_packing_set)
                    idx += 1
        return

    def loaded_simulation_default(self, state: PackingState) -> tuple[float, float]:
        """
        Simulate loading according to the default rule, return the fitness value of simulating loading from a state
        until all blocks are completely loaded.
        """
        # 首先按照默认规则进行装载
        self.load_blocks_default(state)
        # 如果装载容器大于1
        if len(state.packing_sets) > 1:
            level = 1
            while True:
                new_state = self.reset_packing_state(state, level)
                self.load_blocks_default(new_state)
                if new_state == state or level == len(state.packing_sets) - 1:
                    break
                else:
                    state = new_state
                    level += 1
        # 针对每个packing_set计算装载率及边界情况
        for packing_set in state.packing_sets:
            packing_set.evaluate(self.params)
        # 计算装载方案fitness
        state.evaluate(self.params)
        return state.fitness, state.avg_load_rate

    def find_best_direction_loaded(self, block: Block, space: Space, packing_set: PackingSet) -> tuple[bool, Block, Location, int]:
        """
        Determine the optimal direction of block placement based on the touch area with other loaded blocks and container
        after the block loaded in the space.
        """
        best_fitness = -sys.float_info.max
        best_location = Location(-1, -1, -1)
        best_block = Block()
        best_rotation = -1  # 标识block的最佳装载方向
        loaded = False  # 标识当前block在当前子空间能否装载成功
        # 第一个方向是它本身的方向
        b1 = copy.deepcopy(block)
        check1, location1 = self.check_loadable(b1, space, packing_set.loaded_boxes, packing_set.spaces)
        if check1:
            loaded = True
            f = self.get_touch_area_of_block_in_space(b1, location1, packing_set)
            if f > best_fitness:
                best_fitness = f
                best_location = location1
                best_block = b1
                best_rotation = 1
        # 第二个方向是它的宽和长互换
        b2 = copy.deepcopy(block)
        b2.l, b2.w = block.w, block.l
        check2, location2 = self.check_loadable(b2, space, packing_set.loaded_boxes, packing_set.spaces)
        if check2:
            loaded = True
            f = self.get_touch_area_of_block_in_space(b2, location2, packing_set)
            if f > best_fitness:
                best_fitness = f
                best_location = location2
                best_block = b2
                best_rotation = 2
            elif f == best_fitness:
                best_block, best_location, best_rotation = self.get_limited_loaded(b1, b2, location1, location2, space)
        if loaded:
            return True, best_block, best_location, best_rotation
        else:
            return False, block, Location(-1, -1, -1), best_rotation

    # =============================================== 同层装载类函数 ===============================================
    def get_unloaded_blocks_of_similar_height(self, block_dict: dict, heights: list, iden: int, layer: int) -> dict:
        """
        根据block_dict返回可以进行同层装载的new_block_dict，其中key是max_h，value是block list.
        """
        new_block_dict = dict()

        for h in heights:
            current_area = 0.0
            current_blocks = list()
            for h1 in heights:
                if 0 <= h - h1 <= self.params.height_diff_in_one_layer:
                    for block in block_dict[h1]:
                        # 正常板件，完全可以放入
                        if max(block.l, block.w) <= self.params.max_load_length:
                            current_area += block.volume / block.h
                            current_blocks.append(block)
                        # 次超长板件
                        elif max(block.l, block.w) <= self.params.max_load_length + 200 and iden <= 1 and layer > 0:
                            current_area += block.volume / block.h
                            current_blocks.append(block)
                        # 超长板件
                        elif max(block.l, block.w) > self.params.max_load_length + 200 and iden == 0 and layer > 0:
                            current_area += block.volume / block.h
                            current_blocks.append(block)
            # 粗略判断是否满足同层装载条件
            if current_area >= self.params.load_rate_relax * self.params.max_load_length * self.params.max_load_width:
                new_block_dict[h] = current_blocks
        return new_block_dict

    def get_same_layer_loaded_packing_state(self, block_dict: dict, heights: list) -> PackingState:
        """
        Get the best loading solution of similar height blocks loaded in the same layer.
        """
        # 标记已经进行同层装载的block
        same_layer_loaded_blocks = []
        # 标记突出装载的次数
        iden = 0
        if self.params.max_length > self.params.max_load_length + 200:
            iden = 2
        elif self.params.max_length > self.params.max_load_length:
            iden = 1
            # 装载空间信息
        current_l = self.params.max_load_length
        layer_h = 0.0
        layer = 1
        # 初始化packing state
        packing_state = PackingState()
        packing_set = PackingSet()
        packing_set.initialize()
        packing_state.packing_sets.append(packing_set)
        # 存放未能进行同层装载的block
        left_blocks = []
        # 开始逐层装载
        while True:
            # 获取当前层可以进行同层装载的block_dict
            new_block_dict = self.get_unloaded_blocks_of_similar_height(block_dict, heights, iden, layer)
            # it's time to end similar height loading
            if len(new_block_dict) == 0:
                for h in block_dict.keys():
                    for block in block_dict[h]:
                        left_blocks.append(block)
                break
            # it's time to start similar height loading
            best_load_rate = -1  # 记录当前层最佳装载率
            loaded = False  # 记录当前层是否装载成功
            best_state = None  # 记录当前层最佳装载状态
            best_loaded_blocks = []  # 记录当前层最佳装载的block
            best_h = 0.0  # 记录当前层最佳装载的block高度
            for h in new_block_dict.keys():
                current_packing_state = copy.deepcopy(packing_state)  # 对当前packing state进行备份
                current_packing_state.unloaded_blocks = new_block_dict[h]  # 当前层待装载block
                # 装载空间信息
                start = Location(0, 0, layer_h)  # 记录本层space起点
                shape = Shape(current_l, self.params.max_load_width, h)  # 记录本层space形状
                if layer > 1:
                    if iden == 1:
                        start.x = -100
                    else:
                        start.x = -int(math.ceil(current_l - self.params.max_load_length) / 2)
                space = Space(start, shape, 0, 0, 0, 0)
                current_packing_state.packing_sets[-1].spaces = [space]  # add space to the packing set
                current_packing_state.packing_sets[-1].start = start  # set the start of the packing set
                # 计算使用高度为h的block list进行同层装载的最佳装载方案
                current_loaded, current_load_rate, current_best_state, current_loaded_blocks, current_h = \
                    self.make_best_loaded_in_same_layer(layer, current_packing_state)
                if current_loaded:
                    loaded = True  # 只要有一个满足同层装载条件的block list，即可进行同层装载
                    if current_load_rate > best_load_rate:
                        best_load_rate = current_load_rate
                        best_state = current_best_state
                        best_loaded_blocks = current_loaded_blocks
                        best_h = current_h
                    # 如果装载率相同，则选择更厚的block进行装载
                    elif current_load_rate == best_load_rate and current_h > best_h:
                        best_load_rate = current_load_rate
                        best_state = current_best_state
                        best_loaded_blocks = current_loaded_blocks
                        best_h = current_h
            # 如果装载成功
            if loaded:
                self.logger.info(f"Layer {layer} loaded successfully, and the BEST load rate is {best_load_rate:.2f}")
                # 装载状态更新
                packing_state = copy.deepcopy(best_state)
                same_layer_loaded_blocks.extend(best_loaded_blocks)  # 将已经装载的block加入到same_layer_loaded_blocks中
                # 待装载block更新
                need_remove = []  # 记录需要从block_dict中移除的已装载block
                for block in best_loaded_blocks:
                    for block_list in block_dict.values():
                        for block_other in block_list:
                            if self.is_crossed_blocks(block, block_other) and block_other not in need_remove:
                                need_remove.append(block_other)
                if len(need_remove) > 0:
                    for block in need_remove:
                        block_dict[block.h].remove(block)
                # 装载空间更新
                layer_h += best_h
                layer += 1
                if iden == 2:
                    current_l = self.params.max_load_length + 200
                    iden -= 1
                elif iden == 1:
                    current_l = self.params.max_length
                    iden -= 1
            else:
                # 如果全部装载失败则表明无法进行同层装载
                for h in block_dict.keys():
                    for block in block_dict[h]:
                        if block not in left_blocks:
                            left_blocks.append(block)
                break
        # 设置收尾空间
        next_start = Location(-int(math.ceil(current_l - self.params.max_load_length) / 2), 0, layer_h)
        end_space = Space(next_start, Shape(current_l, self.params.max_load_width, self.params.max_load_height - layer_h), 0, 0, 0, 0)
        packing_state.packing_sets[-1].spaces = [end_space]
        packing_state.packing_sets[-1].start = next_start
        # 设置未装载blocks
        for b1 in same_layer_loaded_blocks:
            for b2 in left_blocks:
                if self.is_crossed_blocks(b1, b2):
                    left_blocks.remove(b2)
        packing_state.unloaded_blocks = left_blocks
        return packing_state

    def make_best_loaded_in_same_layer(self, layer: int, packing_state: PackingState) -> tuple[bool, float, PackingState, list]:
        """
        Given some blocks which have the same height, to find the best loading solution of these blocks in the same layer.
        Return if the layer is loaded successfully and best loading solution.
        """
        # 记录本层起点
        start = packing_state.packing_sets[-1].start
        # 记录本层装载的block
        loaded_blocks = []
        # 记录本层最佳装载状态
        best_loaded_area = -1
        best_state = copy.deepcopy(packing_state)
        # 由于层中第一个装载的block会严重影响该层的整体装载率，因此对于第一个装载的block遍历所有block进行实验装载
        for i in range(len(packing_state.unloaded_blocks)):
            # 选取第一个block
            first_block = copy.deepcopy(packing_state.unloaded_blocks[i])
            check, location = self.check_loadable(first_block, packing_state.packing_sets[-1].spaces[0], packing_state.packing_sets[-1].loaded_boxes, packing_state.packing_sets[-1].spaces)
            if check:
                current_loaded = [first_block]  # 装载第一块block
                current_loaded_area = first_block.volume / first_block.h  # 记录当前装载的面积
                current_packing_state = copy.deepcopy(packing_state)
                current_packing_set = current_packing_state.packing_sets[-1]
                self.make_block_loaded(first_block, location, current_packing_set, current_packing_state)
                # 剩余空间装载其他block
                other_blocks, other_area = self.make_blocks_loaded_in_same_height_spaces(current_packing_set, current_packing_state)
                current_loaded.extend(other_blocks)
                current_loaded_area += other_area
                # 寻找最优装载状态
                if current_loaded_area > best_loaded_area:
                    best_loaded_area = current_loaded_area
                    best_state = current_packing_state
                    loaded_blocks = current_loaded
        # 计算本层有效空间大小
        space_l = packing_state.packing_sets[-1].spaces[0].shape.l
        space_w = packing_state.packing_sets[-1].spaces[0].shape.w
        space_h = 0.0
        if len(loaded_blocks) > 0:
            space_h = max(loaded_blocks[0].h, space_h)
        # 判断该层是否适合装载
        if space_l * space_w * space_h == 0:
            load_rate = 0.0
        else:
            load_rate = best_loaded_area / (space_l * space_w)
        self.logger.info('The CURRENT load rate of layer %d is %.2f' % (layer, load_rate))

        if load_rate >= self.params.load_rate_same_layer:
            return True, load_rate, best_state, loaded_blocks, space_h
        elif load_rate >= self.params.load_rate_relax and layer > 1:
            return True, load_rate, best_state, loaded_blocks, space_h
        else:
            for block in loaded_blocks:
                block.already_loaded = False
                block.not_fit_exact_combination += 1
            return False, 0.0, best_state, [], 0.0

    def make_blocks_loaded_in_same_height_spaces(self, packing_set: PackingSet, packing_state: PackingState) -> tuple[list, float]:
        """
        Simulate the loading of blocks in a set of spaces until all spaces are not available, return the current loaded
        blocks and loaded area.
        """
        loaded_area = 0.0
        loaded_blocks = []
        while len(packing_state.unloaded_blocks) > 0 and len(packing_set.spaces) > 0:
            packing_set.spaces.sort(key=cmp_to_key(compare_space))  # 对空闲子空间按照一定规则进行排序
            loaded, block, location = self.find_best_block_loaded_in_single_space(packing_state.unloaded_blocks, packing_set.spaces[0], packing_set)
            if loaded:
                loaded_blocks.append(block)
                loaded_area += block.volume / block.h
                self.make_block_loaded(block, location, packing_set, packing_state)  # 如果可以装载则进行装载
            else:
                packing_set.spaces.pop(0)
        return loaded_blocks, loaded_area

    def find_best_block_loaded_in_single_space(self, blocks: list, space: Space, packing_set: PackingSet) -> tuple[bool, Block, Location]:
        """
        Iterate all the block and find an optimal block to load in the specific space, according to fitness function.
        """
        loaded = False
        best_block = Block()
        best_location = Location(-1, -1, -1)
        best_rotation = -1
        best_fitness = -sys.float_info.max  # 记录最佳适应度值
        for block in blocks:
            current_loaded, current_location = self.check_loadable(block, space, packing_set.loaded_boxes, packing_set.spaces)
            if current_loaded:
                loaded = True
                current_fitness = self.get_fitness_of_block_loaded(block, current_location, space)
                if current_fitness > best_fitness:
                    best_block = block
                    best_location = current_location
                    best_fitness = current_fitness
        return loaded, best_block, best_location


    # =============================================== 装载block后的动态更新函数 ===============================================
    def update_unloaded_blocks(self, blocks: list, loaded_block: Block) -> list:
        """
        Update the unloaded blocks after loading a block
        """
        unloaded_blocks = []
        for block in blocks:
            can_add = True  # whether the block can be added to the unloaded blocks
            for box in block.boxes:
                # 一旦block中有一个box与已装载的block中的box有重叠，则不能加入
                if box in loaded_block.boxes:
                    can_add = False
                    break
            if can_add:
                unloaded_blocks.append(block)
        return unloaded_blocks

    def make_box_loaded(self, block: Block, location: Location, direction=1) -> None:
        """
        Make the boxes of a block loaded in a specific location, and Label the order in which the boxes are loaded.
        """
        for i in range(len(block.boxes)):
            block.boxes[i].already_loaded = True
            if direction == 2:
                # 交换长宽
                temp = block.boxes[i].l
                block.boxes[i].l = block.boxes[i].w
                block.boxes[i].w = temp
                # 交换相对位置
                location_temp = block.relative_location[i].x
                block.relative_location[i].x = block.relative_location[i].y
                block.relative_location[i].y = location_temp
            if block.boxes[i].l == block.boxes[i].origin_l:
                block.boxes[i].direction = 0
            else:
                block.boxes[i].direction = 90
            block.boxes[i].location = Location(location.x + block.relative_location[i].x,
                                               location.y + block.relative_location[i].y,
                                               location.z + block.relative_location[i].z)
        return

    def make_block_loaded(self, block: Block, location: Location, packing_set: PackingSet, packing_state: PackingState, direction=1) -> None:
        """
        Make a block loaded in a specific location
        """
        block.already_loaded = True
        block.location = location
        # 标记装载状态
        packing_set.loaded_blocks.append(block)
        # 记录已装载的boxes
        self.make_box_loaded(block, location, direction=direction)
        packing_set.loaded_boxes.extend(block.boxes)
        packing_set.loaded_volume += block.volume
        # update free subspaces
        self.update_subspaces(packing_set.spaces, block, location)
        # update unloaded blocks
        packing_state.unloaded_blocks = self.update_unloaded_blocks(packing_state.unloaded_blocks, block)
        return

    # =============================================== 装载可行性函数 ===============================================
    def get_loadable_positions(self, block: Block, space: Space) -> list:
        """
        Get loadable positions for a block in a space.
        """
        positions = [
            Location(-1000, -1000, -1000), Location(-1000, -1000, -1000), Location(-1000, -1000, -1000), Location(-1000, -1000, -1000),
            Location(-1000, -1000, -1000)
        ]  # 总共可能有5个候选位置
        may_load = [True, True, True, True, True]
        # x direction
        if space.anchor_index[0] == 1:
            positions[0].x = space.location.x + space.shape.l - block.l
            if space.front > 0:
                positions[1].x = space.location.x + space.shape.l + space.front - block.l
                if block.l * (1 - self.params.min_support_area_rate) <= space.front:
                    positions[2].x = space.location.x + space.shape.l - block.l * self.params.min_support_area_rate
                else:
                    may_load[2] = False
            else:
                may_load[1] = False
                may_load[2] = False
            positions[3].x = space.location.x + space.shape.l - block.l
            positions[4].x = space.location.x + space.shape.l - block.l
        else:
            positions[0].x = space.location.x
            if space.back > 0:
                positions[1].x = space.location.x - space.back
                if block.l * (1 - self.params.min_support_area_rate) <= space.back:
                    positions[2].x = space.location.x - block.l * (1 - self.params.min_support_area_rate)
                else:
                    may_load[2] = False
            else:
                may_load[1] = False
                may_load[2] = False
            positions[3].x = space.location.x
            positions[4].x = space.location.x
        # y direction
        if space.anchor_index[1] == 1:
            positions[0].y = space.location.y + space.shape.w - block.w
            if space.right > 0:
                positions[3].y = space.location.y + space.shape.w + space.right - block.w
                if block.w * (1 - self.params.min_support_area_rate) <= space.right:
                    positions[4].y = space.location.y + space.shape.w - block.w * self.params.min_support_area_rate
                else:
                    may_load[4] = False
            else:
                may_load[3] = False
                may_load[4] = False
            positions[1].y = space.location.y + space.shape.w - block.w
            positions[2].y = space.location.y + space.shape.w - block.w
        else:
            positions[0].y = space.location.y
            if space.left > 0:
                positions[3].y = space.location.y - space.left
                if block.w * (1 - self.params.min_support_area_rate) <= space.left:
                    positions[4].y = space.location.y - block.w * (1 - self.params.min_support_area_rate)
                else:
                    may_load[4] = False
            else:
                may_load[3] = False
                may_load[4] = False
            positions[1].y = space.location.y
            positions[2].y = space.location.y
        # z direction
        for p in positions:
            p.z = space.location.z
        return positions, may_load

    def check_loadable(self, block: Block, space: Space, loaded_boxes: list, spaces: list) -> tuple[bool, Location]:
        """
        Check if the block can be loaded in the space.
        If the block can be loaded return the loaded location, otherwise return location(-1, -1, -1)
        """
        if space.back + space.front + space.shape.l < block.l or space.left + space.right + space.shape.w < block.w or space.shape.h < block.h:
            return False, Location(-1, -1, -1)
        # get loadable positions
        positions, may_load = self.get_loadable_positions(block, space)
        for i in range(len(positions)):
            if not may_load[i]:
                continue
            # 检查装载尺寸是否合适
            if positions[i].x + block.l <= space.location.x + space.shape.l + space.front and \
                    positions[i].y + block.w <= space.location.y + space.shape.w + space.right:
                # 检查装载稳定性是否合适
                if self.check_direct_supportable(block, positions[i], loaded_boxes) and self.check_indirect_supportable(block, positions[i], spaces):
                    return True, Location(positions[i].x, positions[i].y, positions[i].z)
        return False, Location(-1, -1, -1)

    def check_direct_supportable(self, block: Block, location: Location, loaded_boxes: list) -> bool:
        """
        Check the direct support rate of the block.(whether the boxes below the block can support the block)
        """
        if location.z == 0:
            return True
        touch_area = 0.0
        for loaded_box in loaded_boxes:
            x1 = max(location.x, loaded_box.location.x)
            x2 = min(location.x + block.l, loaded_box.location.x + loaded_box.l)
            y1 = max(location.y, loaded_box.location.y)
            y2 = min(location.y + block.w, loaded_box.location.y + loaded_box.w)
            z1 = max(location.z, loaded_box.location.z)
            z2 = min(location.z + block.h, loaded_box.location.z + loaded_box.h)
            # 如果在三个投影面都有图形重叠，则返回false
            if x1 < x2 and y1 < y2 and z1 < z2:
                return False
            if 0 <= location.z - (loaded_box.location.z + loaded_box.h) <= self.params.height_diff_in_one_layer:
                touch_area += max(x2 - x1, 0) * max(y2 - y1, 0)
        return touch_area >= self.params.min_support_area_rate * block.l * block.w

    def check_indirect_supportable(self, block: Block, location: Location, spaces: list) -> bool:
        """
        Check the indirect support rate of the block.(whether the free spaces below the block satisfies certain conditions)
        """
        if location.z == 0:
            return True
        projected_area = 0.0
        for space in spaces:
            # 只考虑纵坐标小于block装载位置纵坐标的空白区域
            if space.location.z < location.z - self.params.height_diff_in_one_layer:
                x1 = max(location.x, space.location.x - space.back)
                x2 = min(location.x + block.l, space.location.x + space.shape.l + space.front)
                y1 = max(location.y, space.location.y - space.left)
                y2 = min(location.y + block.w, space.location.y + space.shape.w + space.right)
                projected_area = max(max(x2 - x1, 0) * max(y2 - y1, 0), projected_area)  # 取最大的投影面积
        return projected_area <= self.params.max_projected_area_rate * block.l * block.w

    # =============================================== 子空间更新函数 ===============================================
    def update_subspaces(self, spaces: list, block: Block, location: Location) -> None:
        """
        Update subspaces after loading a block
        """
        new_spaces = []
        can_removable_spaces = []
        # split spaces
        for space in spaces:
            x1 = min(space.location.x + space.shape.l + space.front, location.x + block.l)
            x2 = max(space.location.x - space.back, location.x)
            y1 = min(space.location.y + space.shape.w + space.right, location.y + block.w)
            y2 = max(space.location.y - space.left, location.y)
            z1 = min(space.location.z + space.shape.h, location.z + block.h)
            z2 = max(space.location.z, location.z)
            # check if the free space overlaps with block
            if x1 > x2 and y1 > y2 and z1 > z2:
                can_removable_spaces.append(space)
                # 处理前面的空闲子空间
                if space.location.x + space.shape.l > location.x + block.l + self.params.gap:
                    front = Space(Location(location.x + block.l + self.params.gap, space.location.y, space.location.z),
                                  Shape(space.location.x + space.shape.l - (location.x + block.l + self.params.gap), space.shape.w, space.shape.h),
                                  space.front, 0, space.left, space.right)
                    front.set_anchor(self.params)
                    new_spaces.append(front)
                # 处理后面的空闲子空间
                if location.x - self.params.gap > space.location.x:
                    back = Space(space.location, Shape(location.x - space.location.x - self.params.gap, space.shape.w, space.shape.h),
                                 0, space.back, space.left, space.right)
                    back.set_anchor(self.params)
                    new_spaces.append(back)
                # 处理左边的空闲子空间
                if space.location.y < location.y - self.params.gap:
                    left = Space(space.location, Shape(space.shape.l, location.y - space.location.y - self.params.gap, space.shape.h),
                                 space.front, space.back, space.left, 0)
                    left.set_anchor(self.params)
                    new_spaces.append(left)
                # 处理右边的空闲子空间
                if space.location.y + space.shape.w - (location.y + block.w + self.params.gap) > 0:
                    right = Space(Location(space.location.x, location.y + block.w + self.params.gap, space.location.z),
                                  Shape(space.shape.l, space.location.y + space.shape.w - (location.y + block.w + self.params.gap), space.shape.h),
                                  space.front, space.back, 0, space.right)
                    right.set_anchor(self.params)
                    new_spaces.append(right)
                # 处理下方空闲子空间
                if location.z - space.location.z > 0:
                    below = Space(space.location, Shape(space.shape.l, space.shape.w, location.z - space.location.z),
                                  space.front, space.back, space.left, space.right)
                    below.set_anchor(self.params)
                    new_spaces.append(below)
                # 处理上方空闲子空间
                if space.location.z + space.shape.h - (location.z + block.h) > 0:
                    above = Space(
                        Location(max(space.location.x - space.back, location.x), max(space.location.y - space.left, location.y),
                                 location.z + block.h),
                        Shape(min(block.l, location.x + block.l - (space.location.x - space.back)),
                              min(block.w, location.y + block.w - (space.location.y - space.left)),
                              space.location.z + space.shape.h - (location.z + block.h)),
                        max(0, space.location.x + space.shape.l + space.front - location.x - block.l),
                        max(0, location.x - (space.location.x - space.back)),
                        max(0, location.y - (space.location.y - space.left)),
                        max(0, space.location.y + space.shape.w + space.right - location.y - block.w)
                    )
                    above.set_anchor(self.params)
                    new_spaces.append(above)
        # remove the spaces that can be split
        if len(can_removable_spaces) > 0:
            for space in can_removable_spaces:
                spaces.remove(space)
            can_removable_spaces.clear()
        # merge spaces：首先增加新空间 之后进行合并操作
        spaces.extend(new_spaces)
        spaces.sort(key=lambda x: x.volume, reverse=True)
        for i in range(len(spaces) - 1):
            if spaces[i] in can_removable_spaces:
                continue
            for j in range(i + 1, len(spaces)):
                if spaces[j] in can_removable_spaces:
                    continue
                if spaces[i].location.x <= spaces[j].location.x and spaces[i].location.y <= spaces[j].location.y and \
                        spaces[i].location.z <= spaces[j].location.z:
                    if spaces[i].location.x + spaces[i].shape.l >= spaces[j].location.x + spaces[j].shape.l and \
                            spaces[i].location.y + spaces[i].shape.w >= spaces[j].location.y + spaces[j].shape.w and \
                            spaces[i].location.z + spaces[i].shape.h >= spaces[j].location.z + spaces[j].shape.h:
                        if spaces[i].front >= spaces[j].front and spaces[i].back >= spaces[j].back and spaces[i].left >= spaces[j].left and \
                                spaces[i].right >= spaces[j].right:
                            can_removable_spaces.append(spaces[j])
        if len(can_removable_spaces) > 0:
            for space in can_removable_spaces:
                spaces.remove(space)
        return

    # ================================================ block生成函数系列 ======================================================
    def generate_blocks(self, instance: Instance) -> tuple[dict, list]:
        """
        Generate blocks by combining simple blocks and complex blocks and group which by height.
        """
        block_dict = dict()
        heights = []
        # generate simple blocks
        simple_blocks = self.generate_simple_blocks(instance)
        # add simple blocks to block dict
        for block in simple_blocks:
            if block.h not in block_dict:
                block_dict[block.h] = []
                heights.append(block.h)
            if block not in block_dict[block.h]:
                block_dict[block.h].append(block)
        # generate general blocks
        general_blocks = self.generate_general_blocks(simple_blocks)
        # add general blocks to block dict
        for block in general_blocks:
            if block.h not in block_dict:
                block_dict[block.h] = []
                heights.append(block.h)
            if block not in block_dict[block.h]:
                block_dict[block.h].append(block)
        return block_dict, heights

    def generate_general_blocks(self, blocks: list) -> list:
        """
        Generate general blocks by combining simple blocks
        """
        B = blocks
        PG = []
        PG.extend(B)
        while len(B) < self.params.max_block_num and len(PG) > 0:
            NG = []
            res_num = self.params.max_block_num - len(B)
            for b1 in PG:
                if res_num == 0:
                    break
                for b2 in B:
                    if res_num == 0:
                        break
                    if self.is_crossed_blocks(b1, b2):
                        continue
                    if b1.h == b2.h:
                        # 1. l-direction composite
                        if b1.volume + b2.volume >= self.params.min_composite_flr * max(b1.w, b2.w) * (b1.l + b2.l) * b1.h and b1.l + b2.l <= self.params.max_length:
                            b_l = self.combine_blocks_with_dimension(b1, b2, 'l')
                            if b_l not in NG and b_l not in B:
                                NG.append(b_l)
                                res_num -= 1
                        # 2. w-direction composite
                        if b1.volume + b2.volume >= self.params.min_composite_flr * max(b1.l, b2.l) * (b1.w + b2.w) * b1.h and b1.w + b2.w <= self.params.max_load_width:
                            b_w = self.combine_blocks_with_dimension(b1, b2, 'w')
                            if b_w not in NG and b_w not in B:
                                NG.append(b_w)
                                res_num -= 1
                    # 3. h-direction composite
                    if b1.volume + b2.volume >= self.params.min_composite_flr * max(b1.l, b2.l) * max(b1.w, b2.w) * (b1.h + b2.h) and b1.h + b2.h <= self.params.max_load_height:
                        b_h = self.combine_blocks_with_dimension(b1, b2, 'h')
                        if b_h not in NG and b_h not in B:
                            NG.append(b_h)
                            res_num -= 1
            PG = NG
            for block in NG:
                if len(B) >= self.params.max_block_num:
                    break
                B.append(block)
        return B

    def generate_simple_blocks(self, instance: Instance) -> list:
        """
        Generate simple blocks from the given single box
        """
        blocks = []
        for box in instance.boxes:
            # 1.原方向
            b1 = Block(l=box.l, w=box.w, h=box.h)
            b1.boxes.append(box)
            b1.volume = box.volume
            b1.relative_location.append(Location(0, 0, 0))
            blocks.append(b1)
            # 2.旋转90度
            if box.l <= self.params.max_load_width:
                b2 = Block(l=box.w, w=box.l, h=box.h)
                box_copy = copy.deepcopy(box)
                box_copy.l = box.origin_w
                box_copy.w = box.origin_l
                box_copy.direction = 90
                b2.boxes.append(box_copy)
                b2.volume = box_copy.volume
                b2.relative_location.append(Location(0, 0, 0))
                blocks.append(b2)
        return blocks

    def combine_blocks_with_dimension(self, b1: Block, b2: Block, dimension: str) -> Block:
        """
        Combine two blocks with specific dimension
        """
        if dimension == 'l':
            b = Block(l=b1.l + b2.l, w=max(b1.w, b2.w), h=b1.h)
            b.volume = b1.volume + b2.volume
            # add boxes
            if b1.w >= b2.w:
                b.boxes.extend(b1.boxes)
                b.boxes.extend(b2.boxes)
                b.relative_location.extend(b1.relative_location)
                for location in b2.relative_location:
                    b.relative_location.append(Location(b1.l + location.x, location.y, location.z))
            else:
                b.boxes.extend(b2.boxes)
                b.boxes.extend(b1.boxes)
                b.relative_location.extend(b2.relative_location)
                for location in b1.relative_location:
                    b.relative_location.append(Location(b2.l + location.x, location.y, location.z))
        elif dimension == 'w':
            b = Block(l=max(b1.l, b2.l), w=b1.w + b2.w, h=b1.h)
            b.volume = b1.volume + b2.volume
            # add boxes
            if b1.w >= b2.w:
                b.boxes.extend(b1.boxes)
                b.boxes.extend(b2.boxes)
                b.relative_location.extend(b1.relative_location)
                for location in b2.relative_location:
                    b.relative_location.append(Location(location.x, b1.w + location.y, location.z))
            else:
                b.boxes.extend(b2.boxes)
                b.boxes.extend(b1.boxes)
                b.relative_location.extend(b2.relative_location)
                for location in b1.relative_location:
                    b.relative_location.append(Location(location.x, b2.w + location.y, location.z))
        else:
            b = Block(l=max(b1.l, b2.l), w=max(b1.w, b2.w), h=b1.h + b2.h)
            b.volume = b1.volume + b2.volume
            # add boxes
            if b1.l * b1.w >= b2.l * b2.w:  # 以长边作为衡量标准
                b.boxes.extend(b1.boxes)
                b.boxes.extend(b2.boxes)
                # b.pl = b2.pl
                # b.pw = b2.pw
                b.relative_location.extend(b1.relative_location)
                for location in b2.relative_location:
                    b.relative_location.append(Location(location.x, location.y, b1.h + location.z))
            else:
                b.boxes.extend(b2.boxes)
                b.boxes.extend(b1.boxes)
                # b.pl = b1.pl
                # b.pw = b1.pw
                b.relative_location.extend(b2.relative_location)
                for location in b1.relative_location:
                    b.relative_location.append(Location(location.x, location.y, b2.h + location.z))
        return b

    def is_crossed_blocks(self, block1: Block, block2: Block) -> bool:
        """
        check if two blocks are crossed
        """
        for box1 in block1.boxes:
            if box1 in block2.boxes:
                return True
        return False

    # ================================================ 评价函数系列 ======================================================
    def get_touch_area_of_block_in_space(self, block: Block, location: Location, packing_set: PackingSet) -> float:
        """
        得到一个block放入某一个空闲子空间后与已装载box以及箱体的接触面积
        """
        start = packing_set.start
        loaded_blocks = packing_set.loaded_blocks
        touch_area = 0.0
        # 计算block与箱体前后面的接触面积
        if location.x <= start.x + self.params.min_box_gap:
            touch_area += block.w * block.h
        if location.x + block.l >= self.params.max_load_length - start.x - self.params.min_box_gap:
            touch_area += block.w * block.h
        # 计算block与箱体左右面的接触面积
        if location.y <= self.params.min_box_gap:
            touch_area += block.l * block.h
        if location.y + block.w >= self.params.max_load_width - self.params.min_box_gap:
            touch_area += block.l * block.h
        # 计算block与箱体上下面的接触面积
        if location.z == 0:
            touch_area += block.l * block.w
        if location.z + block.h == self.params.max_load_height:
            touch_area += block.l * block.w
        # 计算block与其他block的接触面积
        point1_0 = location
        point1_1 = Location(location.x + block.l, location.y + block.w, location.z + block.h)
        for loaded_block in loaded_blocks:
            point2_0 = loaded_block.location
            point2_1 = Location(loaded_block.location.x + loaded_block.l, loaded_block.location.y + loaded_block.w,
                                loaded_block.location.z + loaded_block.h)

            x1 = max(point1_0.x, point2_0.x)
            x2 = min(point1_1.x, point2_1.x)
            y1 = max(point1_0.y, point2_0.y)
            y2 = min(point1_1.y, point2_1.y)
            z1 = max(point1_0.z, point2_0.z)
            z2 = min(point1_1.z, point2_1.z)

            if point2_1.y + self.params.gap == point1_0.y:
                touch_area += max(x2 - x1, 0) * max(z2 - z1, 0)
            if point2_0.y == point1_1.y + self.params.gap:
                touch_area += max(x2 - x1, 0) * max(z2 - z1, 0)
            if point2_1.x + self.params.gap == point1_0.x:
                touch_area += max(y2 - y1, 0) * max(z2 - z1, 0)
            if point2_0.x == point1_1.x + self.params.gap:
                touch_area += max(y2 - y1, 0) * max(z2 - z1, 0)
            if point1_0.z - self.params.height_diff_in_one_layer <= point2_1.z <= point1_0.z:
                touch_area += max(x2 - x1, 0) * max(y2 - y1, 0)
            if point1_1.z <= point2_0.z <= point1_1.z + self.params.height_diff_in_one_layer:
                touch_area += max(x2 - x1, 0) * max(y2 - y1, 0)
        return touch_area

    def get_fitness_of_block_loaded(self, block: Block, location: Location, space: Space) -> float:
        """
        计算一个block放入一个空闲子空间后，与空闲子空间的贴合度
        """
        x11 = max(location.x, space.location.x)
        x21 = min(location.x + block.l, space.location.x + space.shape.l)
        y11 = max(location.y, space.location.y)
        y21 = min(location.y + block.w, space.location.y + space.shape.w)

        return self.params.usage_of_length * (x21 - x11) / (space.shape.l + space.front + space.back) + \
            self.params.usage_of_width * (y21 - y11) / (space.shape.w + space.left + space.right)

    # ================================================ 子空间评价函数系列 ======================================================
    def get_fitness_of_space_1(self, block: Block, location: Location, space: Space, packing_set: PackingSet) -> float:
        """
        根据block与space的接触面积及block的坐标情况计算一个block放入一个空闲子空间后的适应度值
        """
        return self.get_touch_area_of_block_in_space(block, location, packing_set) - self.params.usage_of_height * location.z

    def get_fitness_of_space_2(self, block: Block, location: Location, space: Space, packing_set: PackingSet) -> float:
        """
        根据block对space空间利用率情况计算一个block放入一个空闲子空间后的适应度值
        """
        x11 = max(location.x, space.location.x)
        x21 = min(location.x + block.l, space.location.x + space.shape.l)
        y11 = max(location.y, space.location.y)
        y21 = min(location.y + block.w, space.location.y + space.shape.w)
        return self.params.usage_of_length * (x21 - x11) / (space.shape.l + space.front + space.back) + \
            self.params.usage_of_width * (y21 - y11) / (space.shape.w + space.left + space.right) - \
            self.params.usage_of_height * location.z

    def get_fitness_of_space_3(self, block: Block, location: Location, space: Space, packing_set: PackingSet) -> float:
        """
        根据block的位置信息计算一个block放入一个空闲子空间后的适应度值
        """
        return -math.exp(location.z / 100) - math.exp(location.x / 500) - math.exp(location.y / 250)

    def get_limited_loaded(self, b1: Block, b2: Block, l1: Location, l2: Location, space: Space) -> Tuple[Block, Location, int]:
        """
        当block在space中的两种摆放方向的适应度值相差不大时，选择可以尽可能利用space的摆放方向。默认b1是原方向，b2是旋转后的方向。
        """
        # 检查方向1是否使得space利用率更高
        delta_l_1 = space.location.x + space.shape.l + space.front - l1.x - b1.l
        delta_w_1 = space.location.y + space.shape.w + space.right - l1.y - b1.w

        delta_l_2 = space.location.x + space.shape.l + space.front - l2.x - b2.l
        delta_w_2 = space.location.y + space.shape.w + space.right - l2.y - b2.w

        if min(delta_l_1, delta_w_1) < self.params.min_box_gap + self.params.gap < min(delta_l_2, delta_w_2):
            return b1, l1, 0
        elif min(delta_l_2, delta_w_2) < self.params.min_box_gap + self.params.gap < min(delta_l_1, delta_w_1):
            return b2, l2, 1
        else:  # 没有任何一种情况使得space的某一边成为瓶颈资源，那么长边贴长边，短边贴短边
            if space.shape.l >= space.shape.w:
                return b1, l1, 0  # 原方向就是长边贴长边
            else:
                return b2, l2, 1
