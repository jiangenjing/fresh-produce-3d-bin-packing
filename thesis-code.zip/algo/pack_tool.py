# -*- coding: utf-8 -*-
# @fileName: pack_tool.py
# @Describe: 
# @author: FlySlowly
# @email: [contact redacted]
# @date: 2025/02/21

import copy
import math
from functools import cmp_to_key
from dao.instance import *
import random
from utils.util import *
import time

random.seed(123)

class PackTool:
    def __init__(self, params: Params, logger=None):
        self.params = params
        self.logger = logger

    # =============================================== 主函数 ===============================================
    def main_algo(self, instance: Instance) -> PackingState:
        self.logger.info(f"========================== Calculating {instance.name} ==========================")
        self.logger.info("Start generating blocks...")
        # 生成block
        blocks_dict, heights = self.generate_blocks(instance)
        # self.logger.info("Blocks generated!")
        # 进行同层装载
        self.logger.info('Loading blocks in the same layer...')
        initial_state = self.get_same_layer_loaded_packing_state(blocks_dict, heights)
        initial_state.fitness = -100000
        # self.logger.info('Finish loading blocks in the same layer.')
        # 计算最佳装载方案
        best_state = copy.deepcopy(initial_state)
        width = 1
        self.logger.info("Start beam searching to calculate optimal solution...")
        start_time = time.time()
        while time.time() - start_time < self.params.time_limit and width <= 50:
            best_state = self.beam_search(copy.deepcopy(initial_state), best_state, width)
            width = int(math.ceil(width * math.pow(2, 1 / 2)))
        best_state.evaluate(self.params)
        self.logger.info("Finish calculating the best packing solution and load rate is: " + str(best_state.avg_load_rate))
        self.logger.info(f"=======================================================================================")
        self.logger.info(f"=======================================================================================")
        # 添加box的装载
        for packing_set in best_state.packing_sets:
            for block in packing_set.loaded_blocks:
                self.make_box_loaded(packing_set, block, block.location)
        return best_state

    # =============================================== beam search ===============================================
    def beam_search(self, s0: PackingState, best_state: PackingState, width: int) -> PackingState:
        """
        For the initial state, to find the best loading solution by beam-searching.
        """
        state_que = [s0]
        ite = 0
        while len(state_que) > 0:
            size = len(state_que)
            next_states = dict()
            for i in range(size):
                state = state_que.pop()
                if len(state.unloaded_blocks) == 0:
                    for packing_set in state.packing_sets:
                        packing_set.evaluate(self.params)
                    state.evaluate(self.params)
                    if state.fitness > best_state.fitness:
                        best_state = copy.deepcopy(state)
                        self.logger.info(f"Find a better solution: {best_state.fitness:.5f}")
                    elif state.fitness == best_state.fitness and state.current_load_rate > best_state.current_load_rate:
                        best_state = copy.deepcopy(state)
                        self.logger.info(f"Find a better solution: {best_state.fitness:.5f}")
                    continue
                ite += 1
                # self.logger.info(f"Extending node_{ite}, simulated fitness: {state.fitness:.5f}, current load rate: {state.current_load_rate:.2%}")
                if ite == 1:
                    extended_states = self.extend_state(state, width * width)
                else:
                    extended_states = self.extend_state(state, width)
                for key in extended_states.keys():
                    if extended_states[key][1].fitness > best_state.fitness:
                        best_state = copy.deepcopy(extended_states[key][1])
                        self.logger.info(f"Find a better solution: {best_state.fitness:.5f}")
                    if key in next_states:
                        if next_states[key][0].current_load_rate < extended_states[key][0].current_load_rate:
                            next_states[key] = [extended_states[key][0], extended_states[key][1]]
                    else:
                        next_states[key] = [extended_states[key][0], extended_states[key][1]]
            if next_states:
                sorted_next_states = dict(sorted(next_states.items(), key=lambda x: x[0], reverse=True))
                for key in sorted_next_states:
                    if len(state_que) >= width:
                        break
                    state_que.append(sorted_next_states[key][0])
        return best_state

    def extend_state(self, state: PackingState, width: int) -> dict:
        """
        Extend the current state to the next state.
        """
        extended_states = dict()
        state_copy = copy.deepcopy(state)
        while len(state_copy.unloaded_blocks) > 0:
            packing_set = state_copy.packing_sets[-1]
            while len(packing_set.spaces) > 0:
                packing_set.spaces.sort(key=cmp_to_key(compare_space))
                ranked_blocks = self.get_ranked_blocks_by_csv(packing_set.spaces[0], packing_set, state_copy)
                if len(ranked_blocks) > 0:
                    num = min(width, len(ranked_blocks))
                    for i in range(num):
                        new_state = copy.deepcopy(state_copy)
                        self.make_block_loaded(ranked_blocks[i][0], ranked_blocks[i][1], new_state.packing_sets[-1], new_state)
                        final_state = copy.deepcopy(new_state)
                        self.simulation_default(final_state)
                        new_state.fitness = final_state.fitness
                        new_state.current_load_rate = new_state.calculate_current_load_rate(self.params)
                        if final_state.fitness in extended_states:
                            if extended_states[final_state.fitness][0].current_load_rate < new_state.current_load_rate:
                                extended_states[final_state.fitness] = [new_state, final_state]
                        else:
                            extended_states[final_state.fitness] = [new_state, final_state]
                    break
                else:
                    packing_set.spaces.pop(0)
            # 如果当前空闲空间已不够装载
            if len(packing_set.spaces) == 0 and len(extended_states) == 0:
                packing_set.evaluate(self.params)
                new_packing_set = PackingSet()
                new_packing_set.initialize()
                new_packing_set.spaces = [Space(Location(0, 0, 0),
                                                Shape(self.params.max_length, self.params.max_load_width, self.params.max_load_height), 0, 0, 0, 0)]
                state_copy.packing_sets.append(new_packing_set)
                continue
            if len(extended_states) > 0:
                break
        if len(state_copy.unloaded_blocks) == 0 and len(extended_states) == 0:
            final_state = copy.deepcopy(state)
            extended_states[final_state.fitness] = [state, final_state]
        return extended_states

    def get_ranked_blocks_by_csv(self, space: Space, packing_set: PackingSet, packing_state: PackingState) -> list:
        """
        Get the ranked blocks by VCS value. (Introduce randomness)
        """
        ranked_blocks = []
        for block in packing_state.unloaded_blocks:
            check, location = self.check_loadable(block, space, packing_set.loaded_blocks, packing_set.spaces)
            if check:
                block.vcs = self.calculate_vcs(block, location, packing_set)
                ranked_blocks.append([block, location])
            else:
                block.vcs = -sys.float_info.max
        ranked_blocks.sort(key=lambda x: x[0].vcs, reverse=True)
        return ranked_blocks

    def simulation_default(self, state: PackingState) -> None:
        while len(state.unloaded_blocks) > 0:
            packing_set = state.packing_sets[-1]
            _, _ = self.make_blocks_loaded_in_spaces(packing_set, state)
            if len(state.unloaded_blocks) > 0 and len(packing_set.spaces) == 0:
                packing_set.evaluate(self.params)
                new_packing_set = PackingSet()
                new_packing_set.initialize()
                new_packing_set.spaces = [Space(Location(0, 0, 0),
                                                Shape(self.params.max_length, self.params.max_load_width, self.params.max_load_height), 0, 0, 0, 0)]
                state.packing_sets.append(new_packing_set)
                continue
        state.evaluate(self.params)
        return

    # =============================================== 同层装载相关函数 ===============================================
    def get_unloaded_blocks_of_similar_height(self, block_dict: dict, heights: list, iden: int, layer: int) -> dict:
        """
        根据block_dict返回可以进行同层装载的new_block_dict，其中key是max_h，value是block list.
        """
        new_block_dict = dict()

        for h in heights:
            current_area = 0.0
            current_blocks = list()
            for h1 in heights:
                if 0 <= h - h1 <= self.params.height_diff_in_one_layer:
                    for block in block_dict[h1]:
                        # 正常板件，完全可以放入
                        if max(block.l, block.w) <= self.params.max_load_length:
                            current_area += block.volume / block.h
                            current_blocks.append(block)
                        # 次超长板件
                        elif max(block.l, block.w) <= self.params.max_load_length + 200 and iden <= 1 and layer > 0:
                            current_area += block.volume / block.h
                            current_blocks.append(block)
                        # 超长板件
                        elif max(block.l, block.w) > self.params.max_load_length + 200 and iden == 0 and layer > 0:
                            current_area += block.volume / block.h
                            current_blocks.append(block)
            # 粗略判断是否满足同层装载条件
            if current_area >= self.params.load_rate_relax * self.params.max_load_length * self.params.max_load_width:
                new_block_dict[h] = current_blocks
        return new_block_dict

    def get_same_layer_loaded_packing_state(self, block_dict: dict, heights: list) -> PackingState:
        """
        Get the best loading solution of similar height blocks loaded in the same layer.
        """
        # 标记已经进行同层装载的block
        same_layer_loaded_blocks = []
        # 标记突出装载的次数
        iden = 0
        if self.params.max_length > self.params.max_load_length + 200:
            iden = 2
        elif self.params.max_length > self.params.max_load_length:
            iden = 1
            # 装载空间信息
        current_l = self.params.max_load_length
        layer_h = 0.0
        layer = 1
        # 初始化packing state
        packing_state = PackingState()
        packing_set = PackingSet()
        packing_set.initialize()
        packing_state.packing_sets.append(packing_set)
        # 存放未能进行同层装载的block
        left_blocks = []
        # 开始逐层装载
        while True:
            # 获取当前层可以进行同层装载的block_dict
            new_block_dict = self.get_unloaded_blocks_of_similar_height(block_dict, heights, iden, layer)
            # it's time to end similar height loading
            if len(new_block_dict) == 0:
                for h in block_dict.keys():
                    for block in block_dict[h]:
                        left_blocks.append(block)
                break
            # it's time to start similar height loading
            best_load_rate = -1  # 记录当前层最佳装载率
            loaded = False  # 记录当前层是否装载成功
            best_state = None  # 记录当前层最佳装载状态
            best_loaded_blocks = []  # 记录当前层最佳装载的block
            best_h = 0.0  # 记录当前层最佳装载的block高度
            for h in new_block_dict.keys():
                current_packing_state = copy.deepcopy(packing_state)  # 对当前packing state进行备份
                current_packing_state.unloaded_blocks = new_block_dict[h]  # 当前层待装载block
                # 装载空间信息
                start = Location(0, 0, layer_h)  # 记录本层space起点
                shape = Shape(current_l, self.params.max_load_width, h)  # 记录本层space形状
                if layer > 1:
                    if iden == 1:
                        start.x = -100
                    else:
                        start.x = -int(math.ceil(current_l - self.params.max_load_length) / 2)
                space = Space(start, shape, 0, 0, 0, 0)
                current_packing_state.packing_sets[-1].spaces = [space]  # add space to the packing set
                current_packing_state.packing_sets[-1].start = start  # set the start of the packing set
                # 计算使用高度为h的block list进行同层装载的最佳装载方案
                current_loaded, current_load_rate, current_best_state, current_loaded_blocks, current_h = \
                    self.make_best_loaded_in_same_layer(layer, current_packing_state)
                if current_loaded:
                    loaded = True  # 只要有一个满足同层装载条件的block list，即可进行同层装载
                    if current_load_rate > best_load_rate:
                        best_load_rate = current_load_rate
                        best_state = current_best_state
                        best_loaded_blocks = current_loaded_blocks
                        best_h = current_h
                    # 如果装载率相同，则选择更厚的block进行装载
                    elif current_load_rate == best_load_rate and current_h > best_h:
                        best_load_rate = current_load_rate
                        best_state = current_best_state
                        best_loaded_blocks = current_loaded_blocks
                        best_h = current_h
            # 如果装载成功
            if loaded:
                self.logger.info(f"Layer {layer} loaded successfully, and the BEST load rate is {best_load_rate:.2f}")
                # 装载状态更新
                packing_state = copy.deepcopy(best_state)
                same_layer_loaded_blocks.extend(best_loaded_blocks)  # 将已经装载的block加入到same_layer_loaded_blocks中
                # 待装载block更新
                need_remove = []  # 记录需要从block_dict中移除的已装载block
                for block in best_loaded_blocks:
                    for block_list in block_dict.values():
                        for block_other in block_list:
                            if self.is_crossed_blocks(block, block_other) and block_other not in need_remove:
                                need_remove.append(block_other)
                if len(need_remove) > 0:
                    for block in need_remove:
                        block_dict[block.h].remove(block)
                # 装载空间更新
                layer_h += best_h
                layer += 1
                if iden == 2:
                    current_l = self.params.max_load_length + 200
                    iden -= 1
                elif iden == 1:
                    current_l = self.params.max_length
                    iden -= 1
            else:
                # 如果全部装载失败则表明无法进行同层装载
                for h in block_dict.keys():
                    for block in block_dict[h]:
                        if block not in left_blocks:
                            left_blocks.append(block)
                break
        # 设置收尾空间
        next_start = Location(-int(math.ceil(current_l - self.params.max_load_length) / 2), 0, layer_h)
        end_space = Space(next_start, Shape(current_l, self.params.max_load_width, self.params.max_load_height - layer_h), 0, 0, 0, 0)
        packing_state.packing_sets[-1].spaces = [end_space]
        packing_state.packing_sets[-1].start = next_start
        # 设置未装载blocks
        for b1 in same_layer_loaded_blocks:
            for b2 in left_blocks:
                if self.is_crossed_blocks(b1, b2):
                    left_blocks.remove(b2)
        packing_state.unloaded_blocks = left_blocks
        return packing_state

    def make_best_loaded_in_same_layer(self, layer: int, packing_state: PackingState) -> tuple[bool, float, PackingState, list]:
        """
        Given some blocks which have the same height, to find the best loading solution of these blocks in the same layer.
        Return if the layer is loaded successfully and best loading solution.
        """
        # 记录本层装载的block
        loaded_blocks = []
        # 记录本层最佳装载状态
        best_loaded_volume = -1
        best_state = copy.deepcopy(packing_state)
        packing_set = packing_state.packing_sets[-1]
        for block in packing_state.unloaded_blocks:
            first_block = copy.deepcopy(block)
            check, location = self.check_loadable(first_block, packing_set.spaces[0], packing_set.loaded_blocks, packing_set.spaces)
            if check:
                current_loaded = [first_block]
                current_volume = first_block.volume
                current_state = copy.deepcopy(packing_state)
                current_set = current_state.packing_sets[-1]
                self.make_block_loaded(first_block, location, current_set, current_state)
                # load left blocks
                other_blocks, other_volume = self.make_blocks_loaded_in_spaces(current_set, current_state)
                current_loaded.extend(other_blocks)
                current_volume += other_volume
                if current_volume > best_loaded_volume:
                    best_loaded_volume = current_volume
                    best_state = current_state
                    loaded_blocks = current_loaded
        # 记录本层有效空间大小
        space_l = packing_set.spaces[0].shape.l
        space_w = packing_set.spaces[0].shape.w
        space_h = 0.0
        if len(loaded_blocks) > 0:
            for block in loaded_blocks:
                space_h = max(block.h, space_h)
        # 判断该层是否适合装载
        if space_l * space_w * space_h == 0:
            load_rate = 0.0
        else:
            load_rate = best_loaded_volume / (space_l * space_w * space_h)
        # self.logger.info("Layer %d load rate: %.2f" % (layer, load_rate))
        if load_rate >= self.params.load_rate_same_layer:
            return True, load_rate, best_state, loaded_blocks, space_h
        elif load_rate >= self.params.load_rate_relax and layer > 1:
            return True, load_rate, best_state, loaded_blocks, space_h
        else:
            for block in loaded_blocks:
                block.already_loaded = False
                block.not_fit_exact_combination += 1
            return False, 0.0, best_state, [], 0.0

    # =============================================== 装载工具类函数 ===============================================
    def make_blocks_loaded_in_spaces(self, packing_set: PackingSet, packing_state: PackingState) -> tuple[list, float]:
        """
        Simulate the loading of blocks in a set of spaces until all spaces are not available, return the current loaded
        blocks and loaded volume.
        """
        loaded_volume = 0.0
        loaded_blocks = []
        while len(packing_state.unloaded_blocks) > 0 and len(packing_set.spaces) > 0:
            packing_set.spaces.sort(key=cmp_to_key(compare_space))
            loaded, block, location = self.find_best_block_to_load(packing_state.unloaded_blocks, packing_set.spaces[0], packing_set)
            if loaded:
                self.make_block_loaded(block, location, packing_set, packing_state)
                loaded_blocks.append(block)
                loaded_volume += block.volume
            else:
                packing_set.spaces.pop(0)
        return loaded_blocks, loaded_volume

    def find_best_block_to_load(self, blocks: list, space: Space, packing_set: PackingSet) -> tuple[bool, Block, Location]:
        """
        Find the best block to load in a space
        """
        loaded = False
        best_block = None
        best_location = Location(-1, -1, -1)
        best_val = -sys.float_info.max  # best fitness value
        for block in blocks:
            can_load, location = self.check_loadable(block, space, packing_set.loaded_blocks, packing_set.spaces)
            if can_load:
                loaded = True
                block.vcs = self.calculate_vcs(block, location, packing_set)
                if block.vcs > best_val:
                    best_block = block
                    best_location = location
                    best_val = block.vcs
            else:
                block.vcs = -sys.float_info.max
        return loaded, best_block, best_location

    # =============================================== 装载后的动态更新函数 ===============================================
    def update_unloaded_blocks(self, blocks: list, loaded_block: Block) -> list:
        """
        Update the unloaded blocks after loading a block
        """
        unloaded_blocks = []
        for block in blocks:
            can_add = True  # whether the block can be added to the unloaded blocks
            for box in block.boxes:
                # 一旦block中有一个box与已装载的block中的box有重叠，则不能加入
                if box in loaded_block.boxes:
                    can_add = False
                    break
            if can_add:
                unloaded_blocks.append(block)
        return unloaded_blocks

    def make_box_loaded(self, packing_set: PackingSet, block: Block, location: Location) -> None:
        """
        Make a box loaded in the packing set
        """
        for i in range(len(block.boxes)):
            block.boxes[i].already_loaded = True
            block.boxes[i].location = Location(location.x + block.relative_location[i].x,
                                               location.y + block.relative_location[i].y,
                                               location.z + block.relative_location[i].z)
            packing_set.loaded_boxes.append(block.boxes[i])
        return

    def make_block_loaded(self, block: Block, location: Location, packing_set: PackingSet, packing_state: PackingState) -> None:
        """
        Make a block loaded in a specific location
        """
        block.already_loaded = True
        block.location = location
        # 标记装载状态
        packing_set.loaded_blocks.append(block)
        # # 更新装载boxes
        # self.make_box_loaded(packing_set, block, location)
        packing_set.loaded_volume += block.volume
        # update free subspaces
        self.update_subspaces(packing_set.spaces, block, location)
        # update unloaded blocks
        packing_state.unloaded_blocks = self.update_unloaded_blocks(packing_state.unloaded_blocks, block)
        return

    # =============================================== 装载可行性函数 ===============================================
    def get_loadable_positions(self, block: Block, space: Space) -> list:
        """
        Get loadable positions for a block in a space.
        """
        positions = [
            Location(-1000, -1000, -1000), Location(-1000, -1000, -1000), Location(-1000, -1000, -1000), Location(-1000, -1000, -1000),
            Location(-1000, -1000, -1000)
        ]  # 总共可能有5个候选位置
        may_load = [True, True, True, True, True]
        # x direction
        if space.anchor_index[0] == 1:
            positions[0].x = space.location.x + space.shape.l - block.l
            if space.front > 0:
                positions[1].x = space.location.x + space.shape.l + space.front - block.l
                if block.l * (1 - self.params.min_support_area_rate) <= space.front:
                    positions[2].x = space.location.x + space.shape.l - block.l * self.params.min_support_area_rate
                else:
                    may_load[2] = False
            else:
                may_load[1] = False
                may_load[2] = False
            positions[3].x = space.location.x + space.shape.l - block.l
            positions[4].x = space.location.x + space.shape.l - block.l
        else:
            positions[0].x = space.location.x
            if space.back > 0:
                positions[1].x = space.location.x - space.back
                if block.l * (1 - self.params.min_support_area_rate) <= space.back:
                    positions[2].x = space.location.x - block.l * (1 - self.params.min_support_area_rate)
                else:
                    may_load[2] = False
            else:
                may_load[1] = False
                may_load[2] = False
            positions[3].x = space.location.x
            positions[4].x = space.location.x
        # y direction
        if space.anchor_index[1] == 1:
            positions[0].y = space.location.y + space.shape.w - block.w
            if space.right > 0:
                positions[3].y = space.location.y + space.shape.w + space.right - block.w
                if block.w * (1 - self.params.min_support_area_rate) <= space.right:
                    positions[4].y = space.location.y + space.shape.w - block.w * self.params.min_support_area_rate
                else:
                    may_load[4] = False
            else:
                may_load[3] = False
                may_load[4] = False
            positions[1].y = space.location.y + space.shape.w - block.w
            positions[2].y = space.location.y + space.shape.w - block.w
        else:
            positions[0].y = space.location.y
            if space.left > 0:
                positions[3].y = space.location.y - space.left
                if block.w * (1 - self.params.min_support_area_rate) <= space.left:
                    positions[4].y = space.location.y - block.w * (1 - self.params.min_support_area_rate)
                else:
                    may_load[4] = False
            else:
                may_load[3] = False
                may_load[4] = False
            positions[1].y = space.location.y
            positions[2].y = space.location.y
        # z direction
        for p in positions:
            p.z = space.location.z
        return positions, may_load

    def check_loadable(self, block: Block, space: Space, loaded_blocks: list, spaces: list) -> tuple[bool, Location]:
        """
        Check if the block can be loaded in the space.
        If the block can be loaded return the loaded location, otherwise return location(-1, -1, -1)
        """
        if space.back + space.front + space.shape.l < block.l or space.left + space.right + space.shape.w < block.w or space.shape.h < block.h:
            return False, Location(-1, -1, -1)
        # get loadable positions
        positions, may_load = self.get_loadable_positions(block, space)
        for i in range(len(positions)):
            if not may_load[i]:
                continue
            # 检查装载尺寸是否合适
            if positions[i].x + block.l <= space.location.x + space.shape.l + space.front and \
                    positions[i].y + block.w <= space.location.y + space.shape.w + space.right:
                # 检查装载稳定性是否合适
                if self.check_direct_supportable(block, positions[i], loaded_blocks) and self.check_indirect_supportable(block, positions[i], spaces):
                    return True, Location(positions[i].x, positions[i].y, positions[i].z)
        return False, Location(-1, -1, -1)

    def check_direct_supportable(self, block: Block, location: Location, loaded_blocks: list) -> bool:
        """
        Check the direct support rate of the block.(whether the boxes below the block can support the block)
        """
        if location.z == 0:
            return True
        touch_area = 0.0
        for loaded_block in loaded_blocks:
            x1 = max(location.x, loaded_block.location.x)
            x2 = min(location.x + block.l, loaded_block.location.x + loaded_block.l)
            y1 = max(location.y, loaded_block.location.y)
            y2 = min(location.y + block.w, loaded_block.location.y + loaded_block.w)
            z1 = max(location.z, loaded_block.location.z)
            z2 = min(location.z + block.h, loaded_block.location.z + loaded_block.h)
            # 如果在三个投影面都有图形重叠，则返回false
            if x1 < x2 and y1 < y2 and z1 < z2:
                return False
            if 0 <= location.z - (loaded_block.location.z + loaded_block.h) <= self.params.height_diff_in_one_layer:
                touch_area += max(x2 - x1, 0) * max(y2 - y1, 0)
        return touch_area >= self.params.min_support_area_rate * block.l * block.w

    def check_indirect_supportable(self, block: Block, location: Location, spaces: list) -> bool:
        """
        Check the indirect support rate of the block.(whether the free spaces below the block satisfies certain conditions)
        """
        if location.z == 0:
            return True
        projected_area = 0.0
        for space in spaces:
            # 只考虑纵坐标小于block装载位置纵坐标的空白区域
            if space.location.z < location.z - self.params.height_diff_in_one_layer:
                x1 = max(location.x, space.location.x - space.back)
                x2 = min(location.x + block.l, space.location.x + space.shape.l + space.front)
                y1 = max(location.y, space.location.y - space.left)
                y2 = min(location.y + block.w, space.location.y + space.shape.w + space.right)
                projected_area = max(max(x2 - x1, 0) * max(y2 - y1, 0), projected_area)  # 取最大的投影面积
        return projected_area <= self.params.max_projected_area_rate * block.l * block.w

    # ================================================ 子空间更新函数 ======================================================
    def update_subspaces(self, spaces: list, block: Block, location: Location) -> None:
        """
        Update subspaces after loading a block
        """
        new_spaces = []
        can_removable_spaces = []
        # split spaces
        for space in spaces:
            x1 = min(space.location.x + space.shape.l + space.front, location.x + block.l)
            x2 = max(space.location.x - space.back, location.x)
            y1 = min(space.location.y + space.shape.w + space.right, location.y + block.w)
            y2 = max(space.location.y - space.left, location.y)
            z1 = min(space.location.z + space.shape.h, location.z + block.h)
            z2 = max(space.location.z, location.z)
            # check if the free space overlaps with block
            if x1 > x2 and y1 > y2 and z1 > z2:
                can_removable_spaces.append(space)
                # 处理前面的空闲子空间
                if space.location.x + space.shape.l > location.x + block.l + self.params.gap:
                    front = Space(Location(location.x + block.l + self.params.gap, space.location.y, space.location.z),
                                  Shape(space.location.x + space.shape.l - (location.x + block.l + self.params.gap), space.shape.w, space.shape.h),
                                  space.front, 0, space.left, space.right)
                    front.set_anchor(self.params)
                    new_spaces.append(front)
                # 处理后面的空闲子空间
                if location.x - self.params.gap > space.location.x:
                    back = Space(space.location, Shape(location.x - space.location.x - self.params.gap, space.shape.w, space.shape.h),
                                 0, space.back, space.left, space.right)
                    back.set_anchor(self.params)
                    new_spaces.append(back)
                # 处理左边的空闲子空间
                if space.location.y < location.y - self.params.gap:
                    left = Space(space.location, Shape(space.shape.l, location.y - space.location.y - self.params.gap, space.shape.h),
                                 space.front, space.back, space.left, 0)
                    left.set_anchor(self.params)
                    new_spaces.append(left)
                # 处理右边的空闲子空间
                if space.location.y + space.shape.w - (location.y + block.w + self.params.gap) > 0:
                    right = Space(Location(space.location.x, location.y + block.w + self.params.gap, space.location.z),
                                  Shape(space.shape.l, space.location.y + space.shape.w - (location.y + block.w + self.params.gap), space.shape.h),
                                  space.front, space.back, 0, space.right)
                    right.set_anchor(self.params)
                    new_spaces.append(right)
                # 处理下方空闲子空间
                if location.z - space.location.z > 0:
                    below = Space(space.location, Shape(space.shape.l, space.shape.w, location.z - space.location.z),
                                  space.front, space.back, space.left, space.right)
                    below.set_anchor(self.params)
                    new_spaces.append(below)
                # 处理上方空闲子空间
                if space.location.z + space.shape.h - (location.z + block.h) > 0:
                    above = Space(
                        Location(max(space.location.x - space.back, location.x), max(space.location.y - space.left, location.y),
                                 location.z + block.h),
                        Shape(min(block.l, location.x + block.l - (space.location.x - space.back)),
                              min(block.w, location.y + block.w - (space.location.y - space.left)),
                              space.location.z + space.shape.h - (location.z + block.h)),
                        max(0, space.location.x + space.shape.l + space.front - location.x - block.l),
                        max(0, location.x - (space.location.x - space.back)),
                        max(0, location.y - (space.location.y - space.left)),
                        max(0, space.location.y + space.shape.w + space.right - location.y - block.w)
                    )
                    above.set_anchor(self.params)
                    new_spaces.append(above)
        # remove the spaces that can be split
        if len(can_removable_spaces) > 0:
            for space in can_removable_spaces:
                spaces.remove(space)
            can_removable_spaces.clear()
        # merge spaces：首先增加新空间 之后进行合并操作
        spaces.extend(new_spaces)
        spaces.sort(key=lambda x: x.volume, reverse=True)
        for i in range(len(spaces) - 1):
            if spaces[i] in can_removable_spaces:
                continue
            for j in range(i + 1, len(spaces)):
                if spaces[j] in can_removable_spaces:
                    continue
                if spaces[i].location.x <= spaces[j].location.x and spaces[i].location.y <= spaces[j].location.y and \
                        spaces[i].location.z <= spaces[j].location.z:
                    if spaces[i].location.x + spaces[i].shape.l >= spaces[j].location.x + spaces[j].shape.l and \
                            spaces[i].location.y + spaces[i].shape.w >= spaces[j].location.y + spaces[j].shape.w and \
                            spaces[i].location.z + spaces[i].shape.h >= spaces[j].location.z + spaces[j].shape.h:
                        if spaces[i].front >= spaces[j].front and spaces[i].back >= spaces[j].back and spaces[i].left >= spaces[j].left and \
                                spaces[i].right >= spaces[j].right:
                            can_removable_spaces.append(spaces[j])
        if len(can_removable_spaces) > 0:
            for space in can_removable_spaces:
                spaces.remove(space)
        return

    # ================================================ block生成函数 ======================================================
    def generate_blocks(self, instance: Instance) -> tuple[dict, list]:
        """
        Generate blocks by combining simple blocks and complex blocks and group which by height.
        """
        block_dict = dict()
        heights = []
        # generate simple blocks
        simple_blocks = self.generate_simple_blocks(instance)
        # add simple blocks to block dict
        block_id = 0
        for block in simple_blocks:
            if block.h not in block_dict:
                block_dict[block.h] = []
                heights.append(block.h)
            if block not in block_dict[block.h]:
                block_id += 1
                block.id = block_id
                block_dict[block.h].append(block)
        # generate general blocks
        general_blocks = self.generate_general_blocks(simple_blocks)
        # add general blocks to block dict
        for block in general_blocks:
            if block.h not in block_dict:
                block_dict[block.h] = []
                heights.append(block.h)
            if block not in block_dict[block.h]:
                block_id += 1
                block.id = block_id
                block_dict[block.h].append(block)
        return block_dict, heights

    def generate_general_blocks(self, blocks: list) -> list:
        """
        Generate general blocks by combining simple blocks
        """
        B = blocks
        PG = []
        PG.extend(B)
        while len(B) < self.params.max_block_num and len(PG) > 0:
            NG = []
            res_num = self.params.max_block_num - len(B)
            for b1 in PG:
                if res_num == 0:
                    break
                for b2 in B:
                    if res_num == 0:
                        break
                    if self.is_crossed_blocks(b1, b2):
                        continue
                    if b1.h == b2.h:
                        # 1. l-direction composite
                        if b1.volume + b2.volume >= self.params.min_composite_flr * max(b1.w, b2.w) * (b1.l + b2.l) * b1.h and \
                                b1.l + b2.l <= self.params.max_length:
                            b_l = self.combine_blocks_with_dimension(b1, b2, 'l')
                            if b_l not in NG and b_l not in B:
                                NG.append(b_l)
                                res_num -= 1
                        # 2. w-direction composite
                        if b1.volume + b2.volume >= self.params.min_composite_flr * max(b1.l, b2.l) * (b1.w + b2.w) * b1.h and \
                                b1.w + b2.w <= self.params.max_load_width:
                            b_w = self.combine_blocks_with_dimension(b1, b2, 'w')
                            if b_w not in NG and b_w not in B:
                                NG.append(b_w)
                                res_num -= 1
                    # 3. h-direction composite
                    if b1.volume + b2.volume >= self.params.min_composite_flr * max(b1.l, b2.l) * max(b1.w, b2.w) * (b1.h + b2.h) and \
                            b1.h + b2.h <= self.params.max_load_height:
                        b_h = self.combine_blocks_with_dimension(b1, b2, 'h')
                        if b_h not in NG and b_h not in B:
                            NG.append(b_h)
                            res_num -= 1
            PG = NG
            for block in NG:
                if len(B) >= self.params.max_block_num:
                    break
                B.append(block)
        return B

    def generate_simple_blocks(self, instance: Instance) -> list:
        """
        Generate simple blocks from the given single box
        """
        blocks = []
        for box in instance.boxes:
            # 1.原方向
            b1 = Block(l=box.origin_l, w=box.origin_w, h=box.origin_h)
            b1.boxes.append(copy.deepcopy(box))
            b1.volume = box.volume
            b1.relative_location.append(Location(0, 0, 0))
            blocks.append(b1)
            # 2.旋转90度
            if box.l <= self.params.max_load_width:
                b2 = Block(l=box.origin_w, w=box.origin_l, h=box.h)
                box_copy = copy.deepcopy(box)
                box_copy.l = box.origin_w
                box_copy.w = box.origin_l
                box_copy.direction = 90
                b2.boxes.append(box_copy)
                b2.volume = box_copy.volume
                b2.relative_location.append(Location(0, 0, 0))
                blocks.append(b2)
        return blocks

    def combine_blocks_with_dimension(self, b1: Block, b2: Block, dimension: str) -> Block:
        """
        Combine two blocks with specific dimension
        """
        if dimension == 'l':
            b = Block(l=b1.l + b2.l, w=max(b1.w, b2.w), h=b1.h)
            b.volume = b1.volume + b2.volume
            # add boxes
            if b1.w >= b2.w:
                b.boxes.extend(b1.boxes)
                b.boxes.extend(b2.boxes)
                b.relative_location.extend(b1.relative_location)
                for location in b2.relative_location:
                    b.relative_location.append(Location(b1.l + location.x, location.y, location.z))
            else:
                b.boxes.extend(b2.boxes)
                b.boxes.extend(b1.boxes)
                b.relative_location.extend(b2.relative_location)
                for location in b1.relative_location:
                    b.relative_location.append(Location(b2.l + location.x, location.y, location.z))
        elif dimension == 'w':
            b = Block(l=max(b1.l, b2.l), w=b1.w + b2.w, h=b1.h)
            b.volume = b1.volume + b2.volume
            # add boxes
            if b1.w >= b2.w:
                b.boxes.extend(b1.boxes)
                b.boxes.extend(b2.boxes)
                b.relative_location.extend(b1.relative_location)
                for location in b2.relative_location:
                    b.relative_location.append(Location(location.x, b1.w + location.y, location.z))
            else:
                b.boxes.extend(b2.boxes)
                b.boxes.extend(b1.boxes)
                b.relative_location.extend(b2.relative_location)
                for location in b1.relative_location:
                    b.relative_location.append(Location(location.x, b2.w + location.y, location.z))
        else:
            b = Block(l=max(b1.l, b2.l), w=max(b1.w, b2.w), h=b1.h + b2.h)
            b.volume = b1.volume + b2.volume
            # add boxes
            if b1.l * b1.w >= b2.l * b2.w:  # 以长边作为衡量标准
                b.boxes.extend(b1.boxes)
                b.boxes.extend(b2.boxes)
                b.relative_location.extend(b1.relative_location)
                for location in b2.relative_location:
                    b.relative_location.append(Location(location.x, location.y, b1.h + location.z))
            else:
                b.boxes.extend(b2.boxes)
                b.boxes.extend(b1.boxes)
                b.relative_location.extend(b2.relative_location)
                for location in b1.relative_location:
                    b.relative_location.append(Location(location.x, location.y, b2.h + location.z))
        return b

    def is_crossed_blocks(self, block1: Block, block2: Block) -> bool:
        """
        check if two blocks are crossed
        """
        for box1 in block1.boxes:
            if box1 in block2.boxes:
                return True
        return False

    # ================================================ 评价函数系列 ======================================================
    def calculate_touch_area_of_block_in_space(self, block: Block, location: Location, packing_set: PackingSet) -> float:
        """
        得到一个block放入某一个空闲子空间后与已装载box以及箱体的接触面积
        """
        start = packing_set.start
        loaded_blocks = packing_set.loaded_blocks
        touch_area = 0.0
        # 计算block与箱体前后面的接触面积
        if location.x <= start.x + self.params.min_box_gap:
            touch_area += block.w * block.h
        if location.x + block.l >= self.params.max_load_length - start.x - self.params.min_box_gap:
            touch_area += block.w * block.h
        # 计算block与箱体左右面的接触面积
        if location.y <= self.params.min_box_gap:
            touch_area += block.l * block.h
        if location.y + block.w >= self.params.max_load_width - self.params.min_box_gap:
            touch_area += block.l * block.h
        # 计算block与箱体上下面的接触面积
        if location.z == 0:
            touch_area += block.l * block.w
        if location.z + block.h == self.params.max_load_height:
            touch_area += block.l * block.w
        # 计算block与其他block的接触面积
        point1_0 = location
        point1_1 = Location(location.x + block.l, location.y + block.w, location.z + block.h)
        for loaded_block in loaded_blocks:
            point2_0 = loaded_block.location
            point2_1 = Location(loaded_block.location.x + loaded_block.l, loaded_block.location.y + loaded_block.w,
                                loaded_block.location.z + loaded_block.h)

            x1 = max(point1_0.x, point2_0.x)
            x2 = min(point1_1.x, point2_1.x)
            y1 = max(point1_0.y, point2_0.y)
            y2 = min(point1_1.y, point2_1.y)
            z1 = max(point1_0.z, point2_0.z)
            z2 = min(point1_1.z, point2_1.z)

            if point2_1.y + self.params.gap == point1_0.y:
                touch_area += max(x2 - x1, 0) * max(z2 - z1, 0)
            if point2_0.y == point1_1.y + self.params.gap:
                touch_area += max(x2 - x1, 0) * max(z2 - z1, 0)
            if point2_1.x + self.params.gap == point1_0.x:
                touch_area += max(y2 - y1, 0) * max(z2 - z1, 0)
            if point2_0.x == point1_1.x + self.params.gap:
                touch_area += max(y2 - y1, 0) * max(z2 - z1, 0)
            if point1_0.z - self.params.height_diff_in_one_layer <= point2_1.z <= point1_0.z:
                touch_area += max(x2 - x1, 0) * max(y2 - y1, 0)
            if point1_1.z <= point2_0.z <= point1_1.z + self.params.height_diff_in_one_layer:
                touch_area += max(x2 - x1, 0) * max(y2 - y1, 0)
        return touch_area

    def calculate_vcs(self, block: Block, location: Location, packing_set: PackingSet) -> float:
        """
        Calculate the vcs value after placing a block into space.
        """
        touch_area = self.calculate_touch_area_of_block_in_space(block, location, packing_set)
        surface_area = 2 * (block.l * block.w + block.w * block.h + block.h * block.l)
        ran = random.random() if self.params.random_factor > 0.0 else 1.0

        return block.volume * (touch_area / surface_area) ** self.params.alpha + self.params.random_factor * math.log(ran)




